﻿using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace DiCargoHubApi.Controllers;
[Area("documents")]
[Route("api/[area]")]
[ApiController]
[Authorize]
public class DocumentsController : ControllerBase
{
	private readonly IDocumentService _documentService;

	public DocumentsController(IDocumentService documentService)
	{
		_documentService = documentService;
	}

	[HttpPost("{orderId}/upload")]
	[ProducesResponseType(typeof(DocumentDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Upload(
		[FromRoute] Guid orderId,
		[FromBody] UploadDocumentDto dto
	)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		var document = await _documentService.UploadAsync(orderId, dto);
		return Ok(document);
	}

	[HttpPost("{id}/sign")]
	[ProducesResponseType((int)HttpStatusCode.NoContent)]
	public async Task<IActionResult> Sign(
		[FromRoute] Guid id,
		[FromHeader(Name = "X-Signer-UserId")] Guid signerUserId)
	{
		await _documentService.SignAsync(id, signerUserId);
		return NoContent();
	}

	[HttpGet("{id}")]
	[ProducesResponseType(typeof(DocumentDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetById([FromRoute] Guid id)
	{
		var document = await _documentService.GetByIdAsync(id);
		return Ok(document);
	}

	[HttpGet("order/{orderId}")]
	[ProducesResponseType(typeof(IEnumerable<DocumentDto>), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetByOrder([FromRoute] Guid orderId)
	{
		var list = await _documentService.GetByOrderAsync(orderId);
		return Ok(list);
	}
}
