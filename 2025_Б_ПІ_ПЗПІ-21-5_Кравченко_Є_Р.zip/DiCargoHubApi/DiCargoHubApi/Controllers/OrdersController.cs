﻿using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Filters;
using DiCargoHubApi.BLL.Infrastructure.Models.Order;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace DiCargoHubApi.Controllers;
[Area("orders")]
[Route("api/[area]")]
[ApiController]
[Authorize]
public class OrdersController : ControllerBase
{
	private readonly IOrderService _orderService;

	public OrdersController(IOrderService orderService)
	{
		_orderService = orderService;
	}

	[HttpPost("create")]
	[ProducesResponseType(typeof(OrderDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Create(
		[FromHeader(Name = "X-Customer-UserId")] Guid customerId,
		[FromBody] CreateOrderDto dto
	)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		var order = await _orderService.CreateOrderAsync(customerId, dto);
		return Ok(order);
	}

	[HttpGet("{id}")]
	[ProducesResponseType(typeof(OrderDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetById([FromRoute] Guid id)
	{
		var order = await _orderService.GetByIdAsync(id);
		return Ok(order);
	}

	[HttpGet("details/{id}")]
	[ProducesResponseType(typeof(OrderDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetDetailsById([FromRoute] Guid id)
	{
		var order = await _orderService.GetDetailsByIdAsync(id);
		return Ok(order);
	}

	[HttpPost("search")]
	[ProducesResponseType(typeof(IEnumerable<OrderDto>), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Search([FromBody] OrderFilter filter)
	{
		var list = await _orderService.SearchAsync(filter);
		return Ok(list);
	}

	[HttpPut("{id}")]
	[ProducesResponseType(typeof(OrderDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Update(
		[FromRoute] Guid id,
		[FromBody] UpdateOrderDto dto
	)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		await _orderService.UpdateOrderAsync(id, dto);
		var updated = await _orderService.GetByIdAsync(id);
		return Ok(updated);
	}

	[HttpPut("{id}/status")]
	[ProducesResponseType((int)HttpStatusCode.NoContent)]
	public async Task<IActionResult> UpdateStatus(
		[FromRoute] Guid id,
		[FromBody] UpdateOrderStatusDto dto)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		await _orderService.UpdateStatusAsync(id, dto.Status);
		return NoContent();
	}

	[HttpGet("carrier/{carrierId}")]
	[ProducesResponseType(typeof(IEnumerable<OrderDto>), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetActiveOrdersByCarrier([FromRoute] Guid carrierId)
	{
		var list = await _orderService.GetActiveOrdersByCarrierAsync(carrierId);
		return Ok(list);
	}

	[HttpGet("carrier/{carrierId}/history")]
	[ProducesResponseType(typeof(IEnumerable<OrderDto>), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetHistoryOrdersByCarrier([FromRoute] Guid carrierId)
	{
		var list = await _orderService.GetHistoryOrdersByCarrierAsync(carrierId);
		return Ok(list);
	}
}

public class UpdateOrderStatusDto
{
	public string Status { get; set; } = null!;
}
