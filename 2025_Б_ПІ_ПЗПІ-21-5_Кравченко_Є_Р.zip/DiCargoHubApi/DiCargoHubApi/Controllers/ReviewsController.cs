﻿using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace DiCargoHubApi.Controllers;
[Area("reviews")]
[Route("api/[area]")]
[ApiController]
public class ReviewsController : ControllerBase
{
	private readonly IReviewService _reviewService;

	public ReviewsController(IReviewService reviewService)
	{
		_reviewService = reviewService;
	}

	[HttpPost("{orderId}/add")]
	[ProducesResponseType(typeof(ReviewDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Add(
		[FromRoute] Guid orderId,
		[FromHeader(Name = "X-Reviewer-UserId")] Guid reviewerId,
		[FromBody] CreateReviewDto dto
	)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		var review = await _reviewService.AddReviewAsync(orderId, reviewerId, dto);
		return Ok(review);
	}

	[HttpGet("average/{ratedUserId}")]
	[ProducesResponseType(typeof(decimal), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetAverage([FromRoute] Guid ratedUserId)
	{
		var avg = await _reviewService.GetAverageRatingAsync(ratedUserId);
		return Ok(avg);
	}

	[HttpGet("order/{orderId}")]
	[ProducesResponseType(typeof(IEnumerable<ReviewDto>), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetReviewsByOrder([FromRoute] Guid orderId)
	{
		var reviews = await _reviewService.GetReviewsByOrderAsync(orderId);
		return Ok(reviews);
	}
}
