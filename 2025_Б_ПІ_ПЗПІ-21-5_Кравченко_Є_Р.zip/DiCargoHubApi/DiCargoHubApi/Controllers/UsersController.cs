﻿using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace DiCargoHubApi.Controllers;
[Area("users")]
[Route("api/[area]")]
[ApiController]
[Authorize]
public class UsersController : ControllerBase
{
	private readonly IUserService _userService;

	public UsersController(IUserService userService)
	{
		_userService = userService;
	}

	[HttpGet("profile/{userId}")]
	[ProducesResponseType(typeof(UserProfileDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetProfile([FromRoute] Guid userId)
	{
		var profile = await _userService.GetProfileAsync(userId);
		return Ok(profile);
	}

	[HttpPut("profile/{userId}")]
	[ProducesResponseType((int)HttpStatusCode.NoContent)]
	public async Task<IActionResult> UpdateProfile(
		[FromRoute] Guid userId,
		[FromBody] UpdateProfileDto dto
	)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		await _userService.UpdateProfileAsync(userId, dto);
		return NoContent();
	}
}
