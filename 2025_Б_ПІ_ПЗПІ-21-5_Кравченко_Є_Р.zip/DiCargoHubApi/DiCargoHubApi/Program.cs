using DiCargoHubApi.ApiInfrastructure.Extensions;
using DiCargoHubApi.Infrastructure.Constants;
using DiCargoHubApi.Middleware;

var builder = WebApplication.CreateBuilder(args);
builder.SetDefaultConfiguration();

var app = builder.Build();

app.ApplyMigrations();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
	app.UseSwagger();
	app.UseSwaggerUI();
}

app.UseErrorHandler();

app.UseHttpsRedirection();

app.UseCors(DiCargoHubApiConstants.ALLOW_ANY_ORIGINS);

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();