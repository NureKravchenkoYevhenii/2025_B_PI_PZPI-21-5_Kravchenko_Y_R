﻿using System.Text.Json.Serialization;

namespace DiCargoHubApi.Infrastructure.Enums;
[JsonConverter(typeof(JsonStringEnumConverter<ContractStatus>))]
public enum ContractStatus
{
	Pending,
	Active,
	Completed,
	Cancelled
}