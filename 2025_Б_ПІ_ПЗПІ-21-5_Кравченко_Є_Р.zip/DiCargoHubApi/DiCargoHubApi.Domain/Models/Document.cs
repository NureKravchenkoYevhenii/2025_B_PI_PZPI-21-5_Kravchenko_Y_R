﻿using Newtonsoft.Json;

namespace DiCargoHubApi.Domain.Models;

public class Document : BaseEntity
{
	public string Name { get; set; }

	public string IpfsHash { get; set; }

	public bool SignedByCustomer { get; set; }

	public bool SignedByCarrier { get; set; }

	public Guid OrderId { get; set; }

	#region Relations

	[JsonIgnore]
	public Order Order { get; set; }

	#endregion
}
