﻿using Newtonsoft.Json;

namespace DiCargoHubApi.Domain.Models;
public class RefreshToken : BaseEntity
{
	public Guid Token { get; set; }

	public DateTime ExpiresOn { get; set; }

	public Guid UserId { get; set; }

	#region Relations

	[JsonIgnore]
	public User User { get; set; } = null!;

	#endregion
}
