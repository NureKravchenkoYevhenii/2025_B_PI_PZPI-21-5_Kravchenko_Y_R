﻿using DiCargoHubApi.Infrastructure.Enums;
using Newtonsoft.Json;

namespace DiCargoHubApi.Domain.Models;
public class User : BaseEntity
{
	public string Login { get; set; }

	public string PasswordHash { get; set; }

	public string PasswordSalt { get; set; }

	public DateTime RegistrationDate { get; set; }

	public Role Role { get; set; }

	#region Relations

	[JsonIgnore]
	public ICollection<RefreshToken> RefreshTokens { get; set; }

	[JsonIgnore]
	public ICollection<Transport> Transports { get; set; }

	[JsonIgnore]
	public ICollection<Order> Orders { get; set; }

	[JsonIgnore]
	public ICollection<Offer> Offers { get; set; }

	[JsonIgnore]
	public UserProfile UserProfile { get; set; }

	[JsonIgnore]
	public ICollection<Contract> CustomerContracts { get; set; }

	[JsonIgnore]
	public ICollection<Contract> CarrierContracts { get; set; }

	[JsonIgnore]
	public ICollection<Review> ReceivedReviews { get; set; }

	[JsonIgnore]
	public ICollection<Review> GivenReviews { get; set; }

	#endregion
}
