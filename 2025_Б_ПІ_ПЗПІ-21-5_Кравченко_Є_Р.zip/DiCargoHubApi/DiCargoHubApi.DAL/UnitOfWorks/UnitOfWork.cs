﻿using DiCargoHubApi.DAL.Contracts;
using DiCargoHubApi.DAL.DbContexts;
using DiCargoHubApi.DAL.Repositories;
using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace DiCargoHubApi.DAL.UnitOfWorks;
public class UnitOfWork : IUnitOfWork
{
	private readonly DiCargoHubApiDbContext _dbContext;
	private Dictionary<Type, object> _repositories;
	private bool _disposed = false;

	public UnitOfWork(DiCargoHubApiDbContext dbContext)
	{
		_dbContext = dbContext;
		_repositories = [];
	}

	public virtual IDbContextTransaction BeginTransaction()
	{
		return _dbContext.Database.BeginTransaction();
	}

	public virtual async Task<IDbContextTransaction> BeginTransactionAsync()
	{
		return await _dbContext.Database.BeginTransactionAsync();
	}

	public virtual async Task ExecuteInTransactionAsync(Func<Task> action)
	{
		await using var tx = await _dbContext.Database.BeginTransactionAsync();
		try
		{
			await action();
			await _dbContext.SaveChangesAsync();
			await tx.CommitAsync();
		}
		catch
		{
			await tx.RollbackAsync();
			throw;
		}
	}

	public virtual void Commit()
	{
		_dbContext.SaveChanges();
	}

	public async virtual Task CommitAsync()
	{
		await _dbContext.SaveChangesAsync();
	}

	public virtual void Dispose()
	{
		Dispose(true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing)
			{
				_dbContext.Dispose();
			}

			_disposed = true;
		}
	}

	public virtual Lazy<IRepository<TEntity>> GetLazyRepository<TEntity>()
		where TEntity : BaseEntity
	{
		return new Lazy<IRepository<TEntity>>(GetRepository<TEntity>);
	}

	public virtual IRepository<TEntity> GetRepository<TEntity>()
		where TEntity : BaseEntity
	{
		if (_repositories.ContainsKey(typeof(TEntity)))
		{
			return (IRepository<TEntity>)_repositories[typeof(TEntity)];
		}

		var repository = new Repository<TEntity>(_dbContext);
		_repositories.Add(typeof(TEntity), repository);

		return repository;
	}

	public virtual int ExecuteSqlRaw(string sql, params object[] parameters)
	{
		return _dbContext.Database.ExecuteSqlRaw(sql, parameters);
	}
}
