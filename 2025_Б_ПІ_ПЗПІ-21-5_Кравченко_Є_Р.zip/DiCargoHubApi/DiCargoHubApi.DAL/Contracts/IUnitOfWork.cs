﻿using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore.Storage;

namespace DiCargoHubApi.DAL.Contracts;
public interface IUnitOfWork : IDisposable
{
	void Commit();

	Task CommitAsync();

	IRepository<TEntity> GetRepository<TEntity>()
		where TEntity : BaseEntity;

	Lazy<IRepository<TEntity>> GetLazyRepository<TEntity>()
		where TEntity : BaseEntity;

	IDbContextTransaction BeginTransaction();

	Task<IDbContextTransaction> BeginTransactionAsync();

	Task ExecuteInTransactionAsync(Func<Task> action);

	int ExecuteSqlRaw(string sql, params object[] parameters);
}
