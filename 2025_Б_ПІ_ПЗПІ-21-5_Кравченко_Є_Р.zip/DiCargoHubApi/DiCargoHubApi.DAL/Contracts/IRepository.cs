﻿using DiCargoHubApi.Domain.Models;
using System.Linq.Expressions;

namespace DiCargoHubApi.DAL.Contracts;
public interface IRepository<TEntity>
	where TEntity : BaseEntity
{
	void Add(TEntity entity);

	Task AddAsync(TEntity entity);

	TEntity? GetById(Guid id);

	Task<TEntity?> GetByIdAsync(Guid id);

	TEntity? Get(Expression<Func<TEntity, bool>> predicate);

	IQueryable<TEntity> GetList(Expression<Func<TEntity, bool>> predicate);

	Task<List<TEntity>> GetListAsync(Expression<Func<TEntity, bool>> predicate);

	IQueryable<TEntity> GetAll();

	void Update(TEntity entity);

	void UpdateRange(params TEntity[] entities);

	void Remove(TEntity entity);
}
