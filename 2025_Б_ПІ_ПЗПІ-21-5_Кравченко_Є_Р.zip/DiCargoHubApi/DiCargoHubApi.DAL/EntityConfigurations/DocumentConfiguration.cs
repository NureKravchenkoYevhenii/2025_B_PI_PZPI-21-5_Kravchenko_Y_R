﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using DiCargoHubApi.Domain.Models;

namespace DiCargoHubApi.DAL.EntityConfigurations;
public class DocumentConfiguration : IEntityTypeConfiguration<Document>
{
	public void Configure(EntityTypeBuilder<Document> builder)
	{
		builder.ToTable("Documents");
		builder.HasKey(d => d.Id);

		builder.Property(d => d.Name).IsRequired().HasMaxLength(255);
		builder.Property(d => d.IpfsHash).IsRequired().HasMaxLength(100);
		builder.Property(d => d.SignedByCustomer).IsRequired();
		builder.Property(d => d.SignedByCarrier).IsRequired();

		builder.HasOne(d => d.Order)
			.WithMany(o => o.Documents)
			.HasForeignKey(d => d.OrderId)
			.OnDelete(DeleteBehavior.Cascade);
	}
}