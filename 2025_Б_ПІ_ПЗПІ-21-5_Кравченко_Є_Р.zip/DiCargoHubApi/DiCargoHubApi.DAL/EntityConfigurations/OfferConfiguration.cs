﻿using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.DAL.EntityConfigurations;
public class OfferConfiguration : IEntityTypeConfiguration<Offer>
{
	public void Configure(EntityTypeBuilder<Offer> builder)
	{
		builder.ToTable("Offers");
		builder.HasKey(o => o.Id);

		builder.Property(o => o.Message).IsRequired().HasMaxLength(1000);
		builder.Property(o => o.Status).IsRequired();

		builder.HasOne(o => o.Carrier)
			.WithMany(u => u.Offers)
			.HasForeignKey(o => o.CarrierId)
			.OnDelete(DeleteBehavior.NoAction);

		builder.HasOne(o => o.Order)
			.WithMany(o => o.Offers)
			.HasForeignKey(o => o.OrderId)
			.OnDelete(DeleteBehavior.Cascade);
	}
}
