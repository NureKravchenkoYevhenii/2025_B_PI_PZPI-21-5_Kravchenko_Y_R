﻿using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.DAL.EntityConfigurations;
public class UserProfileConfiguration : IEntityTypeConfiguration<UserProfile>
{
	public void Configure(EntityTypeBuilder<UserProfile> builder)
	{
		builder.ToTable("UserProfiles");
		builder.HasKey(p => p.Id);

		builder.Property(p => p.FirstName).IsRequired().HasMaxLength(100);
		builder.Property(p => p.LastName).IsRequired().HasMaxLength(100);
		builder.Property(p => p.ProfilePicture).IsRequired().HasColumnType("varbinary(max)");
		builder.Property(p => p.Address).IsRequired().HasMaxLength(255);
		builder.Property(p => p.PhoneNumber).IsRequired().HasMaxLength(20);
		builder.Property(p => p.BirthDate).IsRequired();
		builder.Property(p => p.Email).IsRequired().HasMaxLength(100);

		builder.HasOne(p => p.User)
			.WithOne(u => u.UserProfile)
			.HasForeignKey<UserProfile>(p => p.Id)
			.OnDelete(DeleteBehavior.Cascade);
	}
}
