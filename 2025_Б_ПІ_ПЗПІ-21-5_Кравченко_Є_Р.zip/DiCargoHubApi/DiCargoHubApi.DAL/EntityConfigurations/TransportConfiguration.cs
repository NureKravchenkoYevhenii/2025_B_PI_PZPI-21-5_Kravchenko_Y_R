﻿using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.DAL.EntityConfigurations;
public class TransportConfiguration : IEntityTypeConfiguration<Transport>
{
	public void Configure(EntityTypeBuilder<Transport> builder)
	{
		builder.ToTable("Transports");
		builder.HasKey(t => t.Id);

		builder.Property(t => t.LicensePlate).IsRequired().HasMaxLength(20);
		builder.Property(t => t.Capacity).IsRequired();
		builder.Property(t => t.Type).IsRequired();

		builder.HasOne(t => t.Carrier)
			.WithMany(u => u.Transports)
			.HasForeignKey(t => t.CarrierId)
			.OnDelete(DeleteBehavior.Cascade);
	}
}
