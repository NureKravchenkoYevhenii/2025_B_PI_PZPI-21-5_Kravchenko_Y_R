﻿using DiCargoHubApi.BLL.Infrastructure.Models;

namespace DiCargoHubApi.BLL.Contracts;
public interface IAuthService
{
	Task<UserDto> RegisterAsync(RegisterDto dto);

	Task<AuthTokenDto> LoginAsync(LoginDto dto);

	Task<AuthTokenDto> RefreshTokenAsync(Guid refreshToken);
}
