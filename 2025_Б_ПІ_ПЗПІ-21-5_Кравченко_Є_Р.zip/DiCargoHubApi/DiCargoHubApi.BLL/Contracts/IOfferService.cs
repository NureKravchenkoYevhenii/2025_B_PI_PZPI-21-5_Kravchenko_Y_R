﻿using DiCargoHubApi.BLL.Infrastructure.Models.Offer;

namespace DiCargoHubApi.BLL.Contracts;
public interface IOfferService
{
	Task<OfferDto> CreateOfferAsync(Guid carrierId, CreateOfferDto dto);
	
	Task<IEnumerable<OfferDto>> GetByOrderAsync(Guid orderId);
	
	Task AcceptOfferAsync(Guid offerId);

	Task<IEnumerable<OfferDto>> GetPendingByCarrierAsync(Guid carrierId);

	Task DeleteOfferAsync(Guid carrierId, Guid offerId);
}