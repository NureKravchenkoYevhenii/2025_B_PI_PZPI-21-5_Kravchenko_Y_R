﻿using DiCargoHubApi.BLL.Infrastructure.Filters;
using DiCargoHubApi.BLL.Infrastructure.Models.Offer;
using DiCargoHubApi.BLL.Infrastructure.Models.Order;

namespace DiCargoHubApi.BLL.Contracts;
public interface IOrderService
{
	Task<OrderDto> CreateOrderAsync(Guid customerId, CreateOrderDto dto);
	
	Task<OrderDto?> GetByIdAsync(Guid orderId);

	Task<OrderDetailsDto> GetDetailsByIdAsync(Guid orderId);
	
	Task<IEnumerable<OrderDto>> SearchAsync(OrderFilter filter);
	
	Task UpdateStatusAsync(Guid orderId, string newStatus);

	Task UpdateOrderAsync(Guid orderId, UpdateOrderDto dto);

	Task<IEnumerable<OrderDto>> GetActiveOrdersByCarrierAsync(Guid carrierId);

	Task<IEnumerable<OrderDto>> GetHistoryOrdersByCarrierAsync(Guid carrierId);
}
