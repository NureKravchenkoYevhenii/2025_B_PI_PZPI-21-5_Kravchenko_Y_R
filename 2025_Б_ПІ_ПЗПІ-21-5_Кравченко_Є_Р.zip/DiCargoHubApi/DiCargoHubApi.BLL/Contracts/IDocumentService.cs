﻿using DiCargoHubApi.BLL.Infrastructure.Models;

namespace DiCargoHubApi.BLL.Contracts;
public interface IDocumentService
{
	Task<DocumentDto> UploadAsync(Guid orderId, UploadDocumentDto dto);
	
	Task SignAsync(Guid documentId, Guid signerUserId);

	Task<DocumentDto> GetByIdAsync(Guid id);
	
	Task<IEnumerable<DocumentDto>> GetByOrderAsync(Guid orderId);
}
