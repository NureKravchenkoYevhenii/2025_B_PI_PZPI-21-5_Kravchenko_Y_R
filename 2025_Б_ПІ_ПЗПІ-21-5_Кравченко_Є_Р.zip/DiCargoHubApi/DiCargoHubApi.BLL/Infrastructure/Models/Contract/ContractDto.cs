﻿namespace DiCargoHubApi.BLL.Infrastructure.Models.Contract;
public class ContractDto
{
	public Guid Id { get; set; }

	public string IpfsHash { get; set; } = null!;

	public bool SignedByCustomer { get; set; }

	public bool SignedByCarrier { get; set; }

	public string Status { get; set; } = null!;

	public Guid OrderId { get; set; }

	public Guid CustomerId { get; set; }

	public Guid CarrierId { get; set; }
}
