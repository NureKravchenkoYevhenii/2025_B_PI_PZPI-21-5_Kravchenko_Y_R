﻿namespace DiCargoHubApi.BLL.Infrastructure.Models;
public class AuthTokenDto
{
	public string Jwt { get; set; } = string.Empty;

	public Guid RefreshToken { get; set; }
}
