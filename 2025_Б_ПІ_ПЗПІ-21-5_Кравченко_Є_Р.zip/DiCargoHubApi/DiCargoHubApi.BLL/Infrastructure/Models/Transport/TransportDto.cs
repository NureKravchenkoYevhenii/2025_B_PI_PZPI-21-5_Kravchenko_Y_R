﻿namespace DiCargoHubApi.BLL.Infrastructure.Models;
public class TransportDto
{
	public Guid Id { get; set; }
	
	public string LicensePlate { get; set; } = null!;
	
	public double Capacity { get; set; }
	
	public string Type { get; set; } = null!;
	
	public Guid CarrierId { get; set; }
}
