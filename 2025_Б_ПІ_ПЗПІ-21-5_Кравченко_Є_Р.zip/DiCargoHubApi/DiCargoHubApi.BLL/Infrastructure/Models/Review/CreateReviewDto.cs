﻿namespace DiCargoHubApi.BLL.Infrastructure.Models;
public class CreateReviewDto
{
	public Guid RatedUserId { get; set; }

	public int Score { get; set; }

	public string? Comments { get; set; }
}
