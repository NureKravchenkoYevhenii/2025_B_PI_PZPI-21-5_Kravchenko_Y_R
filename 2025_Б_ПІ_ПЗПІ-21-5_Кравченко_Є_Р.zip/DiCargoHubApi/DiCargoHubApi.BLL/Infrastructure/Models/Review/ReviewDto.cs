﻿namespace DiCargoHubApi.BLL.Infrastructure.Models;
public class ReviewDto
{
	public Guid Id { get; set; }

	public Guid OrderId { get; set; }

	public Guid RatedUserId { get; set; }

	public Guid ReviewerId { get; set; }

	public int Score { get; set; }

	public string? Comments { get; set; }
}
