﻿using AutoMapper;
using DiCargoHubApi.BLL.Infrastructure.Models;

namespace DiCargoHubApi.BLL.Infrastructure.Mapper;
public class UserProfileProfile : Profile
{
	public UserProfileProfile()
	{
		CreateMap<Domain.Models.UserProfile, UserProfileDto>()
			.ForMember(dst => dst.Id, opt => opt.MapFrom(src => src.Id));

		CreateMap<UpdateProfileDto, Domain.Models.UserProfile>()
			.ForAllMembers(opt => opt.Condition((src, dest, srcMember) => srcMember != null));
	}
}
