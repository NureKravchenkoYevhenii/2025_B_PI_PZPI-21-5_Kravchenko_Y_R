﻿using AutoMapper;
using DiCargoHubApi.BLL.Infrastructure.Models.Contract;
using DiCargoHubApi.Domain.Models;

namespace DiCargoHubApi.BLL.Infrastructure.Mapper;

public class ContractProfile : Profile
{
	public ContractProfile()
	{
		CreateMap<CreateContractDto, Contract>();

		CreateMap<Contract, ContractDto>()
			.ForMember(dest => dest.Status,
				opt => opt.MapFrom(src => src.Status.ToString()));
	}
}