﻿using AutoMapper;
using DiCargoHubApi.BLL.Infrastructure.Models.Order;
using DiCargoHubApi.Domain.Models;

namespace DiCargoHubApi.BLL.Infrastructure.Mapper;

public class OrderProfile : Profile
{
	public OrderProfile()
	{
		CreateMap<CreateOrderDto, Order>();

		CreateMap<UpdateOrderDto, Order>();

		CreateMap<Order, OrderDto>()
			.ForMember(d => d.CustomerName, opt =>
			{
				opt.PreCondition(src => src.Customer?.UserProfile != null);
				opt.MapFrom(src => $"{src.Customer.UserProfile.FirstName} {src.Customer.UserProfile.LastName}".Trim());
			})
			.ForMember(d => d.Status,
				opt => opt.MapFrom(s => s.Status.ToString()));

		CreateMap<Order, OrderDetailsDto>()
			.ForMember(d => d.CustomerName,
				opt => opt.MapFrom(s => $"{s.Customer.UserProfile.FirstName} {s.Customer.UserProfile.LastName}".Trim()))
			.ForMember(d => d.Status,
				opt => opt.MapFrom(s => s.Status.ToString()));
	}
}
