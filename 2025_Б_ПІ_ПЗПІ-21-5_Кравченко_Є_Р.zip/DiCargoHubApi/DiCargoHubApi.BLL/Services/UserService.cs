﻿using AutoMapper;
using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models;
using DiCargoHubApi.DAL.Contracts;
using DiCargoHubApi.Domain.Models;

namespace DiCargoHubApi.BLL.Services;

public class UserService : IUserService
{
	private readonly IUnitOfWork _uow;
	private readonly IRepository<UserProfile> _profiles;
	private readonly IMapper _mapper;

	public UserService(IUnitOfWork uow, IMapper mapper)
	{
		_uow = uow;
		_mapper = mapper;
		_profiles = _uow.GetRepository<UserProfile>();
	}

	public async Task<UserProfileDto> GetProfileAsync(Guid userId)
	{
		var profile = await _profiles.GetByIdAsync(userId)
			?? throw new KeyNotFoundException($"Profile for user {userId} not found");

		return _mapper.Map<UserProfileDto>(profile);
	}

	public async Task UpdateProfileAsync(Guid userId, UpdateProfileDto dto)
	{
		var profile = await _profiles.GetByIdAsync(userId)
			?? throw new KeyNotFoundException($"Profile for user {userId} not found");

		_mapper.Map(dto, profile);

		_profiles.Update(profile);
		await _uow.CommitAsync();
	}
}
