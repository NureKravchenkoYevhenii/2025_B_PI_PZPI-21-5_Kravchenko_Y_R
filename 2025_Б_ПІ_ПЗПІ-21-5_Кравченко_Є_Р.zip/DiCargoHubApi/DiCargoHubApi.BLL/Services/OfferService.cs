﻿using AutoMapper;
using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models.Offer;
using DiCargoHubApi.DAL.Contracts;
using DiCargoHubApi.Domain.Models;
using DiCargoHubApi.Infrastructure.Enums;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.BLL.Services;
public class OfferService : IOfferService
{
	private readonly IUnitOfWork _uow;
	private readonly IRepository<Offer> _offers;
	private readonly IRepository<Order> _orders;
	private readonly IMapper _mapper;

	public OfferService(IUnitOfWork uow, IMapper mapper)
	{
		_uow = uow;
		_mapper = mapper;
		_offers = _uow.GetRepository<Offer>();
		_orders = _uow.GetRepository<Order>();
	}

	public async Task<OfferDto> CreateOfferAsync(Guid carrierId, CreateOfferDto dto)
	{
		var offer = _mapper.Map<Offer>(dto);
		offer.CarrierId = carrierId;
		offer.Status = OfferStatus.Pending;

		await _offers.AddAsync(offer);
		await _uow.CommitAsync();

		return _mapper.Map<OfferDto>(offer);
	}

	public async Task<IEnumerable<OfferDto>> GetByOrderAsync(Guid orderId)
	{
		var offers = await _offers
			.GetListAsync(o => o.OrderId == orderId);

		return _mapper.Map<List<OfferDto>>(offers);
	}

	public async Task AcceptOfferAsync(Guid offerId)
	{
		await _uow.ExecuteInTransactionAsync(async () =>
		{
			var offer = await _offers.GetByIdAsync(offerId)
				?? throw new KeyNotFoundException($"Offer {offerId} not found");

			offer.Status = OfferStatus.Accepted;
			_offers.Update(offer);

			await RejectOffersExceptOf(offer.Id, offer.OrderId);
			await UpdateOrderStatus(offer.OrderId, OrderStatus.Offered);
		});
	}

	public async Task<IEnumerable<OfferDto>> GetPendingByCarrierAsync(Guid carrierId)
	{
		var offers = await _offers.GetAll()
			.Include(o => o.Carrier)
			.ThenInclude(c => c.UserProfile)
			.Include(o => o.Order)
			.Where(o => o.CarrierId == carrierId && o.Status == OfferStatus.Pending)
			.ToListAsync();

		return _mapper.Map<List<OfferDto>>(offers);
	}

	public async Task DeleteOfferAsync(Guid carrierId, Guid offerId)
	{
		var offer = await _offers.GetByIdAsync(offerId);
		if (offer == null)
			return;

		if (offer.CarrierId != carrierId)
			throw new Exception("Cannot delete offer. Not your offer");

		if (offer.Status == OfferStatus.Accepted)
			throw new Exception("Cannot delete offer. Already accepted");

		_offers.Remove(offer);
		await _uow.CommitAsync();
	}

	protected async Task RejectOffersExceptOf(Guid offerId, Guid orderId)
	{
		var offersToReject = await _offers.GetListAsync(o =>
			o.OrderId == orderId &&
			o.Id != offerId
		);
		if (offersToReject.Count > 0)
		{
			foreach (var offer in offersToReject)
			{
				offer.Status = OfferStatus.Rejected;
			}
			_offers.UpdateRange(offersToReject.ToArray());
		}
	}

	protected async Task UpdateOrderStatus(Guid orderId, OrderStatus status)
	{
		var order = await _orders.GetByIdAsync(orderId);
		if (order != null)
		{
			order.Status = status;
		}
	}
}
