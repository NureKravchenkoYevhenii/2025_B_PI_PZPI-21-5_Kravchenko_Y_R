﻿using AutoMapper;
using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models.Contract;
using DiCargoHubApi.DAL.Contracts;
using DiCargoHubApi.Domain.Models;
using DiCargoHubApi.Infrastructure.Enums;

namespace DiCargoHubApi.BLL.Services;
public class ContractService : IContractService
{
	private readonly IUnitOfWork _uow;
	private readonly IRepository<Contract> _contracts;
	private readonly IRepository<Offer> _offers;
	private readonly IRepository<Order> _orders;
	private readonly IMapper _mapper;

	public ContractService(
		IUnitOfWork uow,
		IMapper mapper)
	{
		_uow = uow;
		_mapper = mapper;
		_contracts = _uow.GetRepository<Contract>();
		_offers = _uow.GetRepository<Offer>();
		_orders = _uow.GetRepository<Order>();
	}

	public async Task<ContractDto> CreateFromOfferAsync(CreateContractDto dto)
	{
		var offer = await _offers.GetByIdAsync(dto.OfferId)
			?? throw new KeyNotFoundException($"Offer {dto.OfferId} not found");

		var order = await _orders.GetByIdAsync(offer.OrderId)
			?? throw new KeyNotFoundException($"Order {offer.OrderId} not found");

		var contract = new Contract
		{
			IpfsHash = string.Empty,
			SignedByCustomer = false,
			SignedByCarrier = false,
			Status = ContractStatus.Pending,
			OrderId = order.Id,
			CustomerId = order.CustomerId,
			CarrierId = offer.CarrierId
		};

		await _contracts.AddAsync(contract);
		await _uow.CommitAsync();

		return _mapper.Map<ContractDto>(contract);
	}

	public async Task SignAsync(Guid contractId, Guid signerUserId)
	{
		var contract = await _contracts.GetByIdAsync(contractId)
			?? throw new KeyNotFoundException($"Contract {contractId} not found");

		if (contract.CustomerId == signerUserId)
			contract.SignedByCustomer = true;
		else if (contract.CarrierId == signerUserId)
			contract.SignedByCarrier = true;
		else
			throw new UnauthorizedAccessException("User is neither customer nor carrier");

		if (contract.SignedByCustomer && contract.SignedByCarrier)
			contract.Status = ContractStatus.Active;

		_contracts.Update(contract);
		await _uow.CommitAsync();
	}

	public async Task<ContractDto> GetByIdAsync(Guid contractId)
	{
		var contract = await _contracts.GetByIdAsync(contractId)
			?? throw new KeyNotFoundException($"Contract {contractId} not found");

		return _mapper.Map<ContractDto>(contract);
	}
}
