﻿using AutoMapper;
using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models;
using DiCargoHubApi.DAL.Contracts;
using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.BLL.Services;
public class ReviewService : IReviewService
{
	private readonly IUnitOfWork _uow;
	private readonly IRepository<Review> _reviews;
	private readonly IRepository<Order> _orders;
	private readonly IRepository<User> _users;
	private readonly IMapper _mapper;

	public ReviewService(
		IUnitOfWork uow,
		IMapper mapper)
	{
		_uow = uow;
		_mapper = mapper;
		_reviews = _uow.GetRepository<Review>();
		_orders = _uow.GetRepository<Order>();
		_users = _uow.GetRepository<User>();
	}

	public async Task<ReviewDto> AddReviewAsync(
		Guid orderId,
		Guid reviewerId,
		CreateReviewDto dto)
	{
		var order = await _orders.GetAll()
			.Include(o => o.Offers)
			.FirstOrDefaultAsync(o => o.Id == orderId)
				?? throw new KeyNotFoundException($"Order {orderId} not found");

		if (order.CustomerId != dto.RatedUserId
			&& order.Offers.FirstOrDefault(o =>
				o.OrderId == orderId &&
				o.CarrierId == dto.RatedUserId
			) == null
		)
		{
			throw new InvalidOperationException(
				$"User {dto.RatedUserId} was not part of order {orderId}");
		}

		if (reviewerId == dto.RatedUserId)
			throw new InvalidOperationException("Cannot review yourself");

		var review = _mapper.Map<Review>(dto);
		review.OrderId = orderId;
		review.ReviewerId = reviewerId;

		await _reviews.AddAsync(review);
		await _uow.CommitAsync();

		return _mapper.Map<ReviewDto>(review);
	}

	public async Task<decimal> GetAverageRatingAsync(Guid ratedUserId)
	{
		var userExists = await _users.GetAll()
			.AnyAsync(u => u.Id == ratedUserId);
		if (!userExists)
			throw new KeyNotFoundException($"User {ratedUserId} not found");

		var allReviews = await _reviews
			.GetListAsync(r => r.RatedUserId == ratedUserId);

		if (allReviews.Count == 0)
			return 0m;

		return (decimal)allReviews.Average(r => r.Score);
	}

	public async Task<IEnumerable<ReviewDto>> GetReviewsByOrderAsync(Guid orderId)
	{
		var reviews = await _reviews.GetListAsync(r => r.OrderId == orderId);
		return _mapper.Map<IEnumerable<ReviewDto>>(reviews);
	}
}
