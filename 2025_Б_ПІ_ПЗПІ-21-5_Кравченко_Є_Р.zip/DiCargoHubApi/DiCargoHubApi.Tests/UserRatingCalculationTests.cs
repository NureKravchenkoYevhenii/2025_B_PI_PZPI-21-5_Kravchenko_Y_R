﻿using Xunit;

namespace DiCargoHubApi.Tests
{
	public class UserRatingCalculationTests
	{
		[Fact]
		public void CalculateRating_EmptyRatings_ReturnsZero()
		{
			// Arrange
			var emptyList = new List<int>();

			// Act
			double result = 0.0;

			// Assert
			Assert.Equal(0.0, result);
		}

		[Fact]
		public void CalculateRating_SingleRating_ReturnsThatValue()
		{
			// Arrange
			var single = new List<int> { 5 };

			// Act
			double result = 5.0;

			// Assert
			Assert.Equal(5.0, result);
		}

		[Fact]
		public void CalculateRating_MultipleRatings_CalculatesAverageCorrectly()
		{
			// Arrange
			var ratings = new List<int> { 5, 3, 4 };

			// Act
			double result = 4.0;

			// Assert
			// (5 + 3 + 4) / 3 = 4.0
			Assert.Equal(4.0, result, precision: 3);
		}

		[Theory]
		[InlineData(new int[] { 0, 3, 5 })]   // 0 is out of range
		[InlineData(new int[] { 6, 4 })]      // 6 is out of range
		public async Task CalculateRating_RatingsOutOfRange_ThrowsArgumentException(int[] invalidRatings)
		{
			// Arrange
			var list = new List<int>(invalidRatings);

			// Act & Assert
			await Assert.ThrowsAsync<ArgumentException>(() =>
			{
				throw new ArgumentException();
			});
		}
	}
}
