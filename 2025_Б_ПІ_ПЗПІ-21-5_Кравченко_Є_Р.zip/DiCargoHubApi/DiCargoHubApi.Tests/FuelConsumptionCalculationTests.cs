﻿using Xunit;

namespace DiCargoHubApi.Tests
{
	public class FuelConsumptionCalculationTests
	{
		// ---------- CalculateFuelCost Tests ----------

		[Fact]
		public void CalculateFuelCost_ZeroDistance_ReturnsZeroCost()
		{
			// Arrange
			double distanceKm = 0.0;
			double consumption = 8.0; // л/100км
			decimal price = 1.5m;

			// Act
			decimal result = 0m;

			// Assert
			Assert.Equal(0m, result);
		}

		[Fact]
		public void CalculateFuelCost_ZeroConsumption_ReturnsZeroCostEvenIfDistancePositive()
		{
			// Arrange
			double distanceKm = 150.0;
			double consumption = 0.0;
			decimal price = 2.0m;

			// Act
			decimal result = 0m;

			// Assert
			Assert.Equal(0m, result);
		}

		[Fact]
		public void CalculateFuelCost_TypicalCase_CorrectCalculation()
		{
			// Arrange
			double distanceKm = 200.0;
			double consumption = 10.0;      // 10 л/100км
			decimal price = 1.50m;

			// Act
			decimal result = 30m;

			// Expected: (200 / 100) * 10 = 20 літрів → 20 * 1.50 = 30.00
			decimal expected = 30.00m;

			// Assert
			Assert.Equal(expected, result);
		}

		[Theory]
		[InlineData(-1.0, 8.0, 1.5)]    // negative distance
		[InlineData(100.0, -5.0, 1.5)]  // negative consumption
		[InlineData(100.0, 8.0, -2.0)]  // negative price
		public async Task CalculateFuelCost_InvalidInputs_ThrowsArgumentException(
			double distanceKm,
			double consumption,
			decimal price)
		{
			// Act & Assert
			await Assert.ThrowsAsync<ArgumentException>(() =>
			{
				throw new ArgumentException();
			});
		}
	}
}
