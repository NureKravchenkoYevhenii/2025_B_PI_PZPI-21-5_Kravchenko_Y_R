﻿namespace DiCargoHubApi.Infrastructure.Helpers;
public class PasswordHelper
{
	private const string DEFAULT_SALT = "98+_)+(_+a?}\">?\\\"kf98bvsocn01234-)(U^)QWEJOFkn9uwe0tj)ASDJF)(H0INHO$%uh09hj";
	private const string SYMBOLS = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm[]'/.,{}:\"<>?`1234567890-=~!@#$%^&*()_+\\|";
	private const int SALT_LENGTH = 16;

	private static readonly Random _random = new((int)(DateTime.Now.Ticks % 181081));

	public static string GenerateSalt() => new string(
		Enumerable.Repeat(SYMBOLS, SALT_LENGTH).Select(s => s[_random.Next(s.Length)]).ToArray()
	);

	public static string Hash(string password, string salt) =>
		BCrypt.Net.BCrypt.HashPassword(password + salt + DEFAULT_SALT);

	public static bool Verify(string password, string salt, string passwordHash) =>
		BCrypt.Net.BCrypt.Verify(password + salt + DEFAULT_SALT, passwordHash);
}
