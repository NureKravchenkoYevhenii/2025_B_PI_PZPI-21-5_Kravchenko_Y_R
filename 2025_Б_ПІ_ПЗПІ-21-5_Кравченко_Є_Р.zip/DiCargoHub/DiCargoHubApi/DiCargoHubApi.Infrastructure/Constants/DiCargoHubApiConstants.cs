﻿namespace DiCargoHubApi.Infrastructure.Constants;
public class DiCargoHubApiConstants
{
	public const string ALLOW_ANY_ORIGINS = "allowAnyOrigins";
}
