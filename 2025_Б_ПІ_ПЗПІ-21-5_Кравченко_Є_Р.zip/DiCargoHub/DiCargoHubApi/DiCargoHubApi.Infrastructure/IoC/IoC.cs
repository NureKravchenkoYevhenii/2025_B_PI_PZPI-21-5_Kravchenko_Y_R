﻿using Autofac;

namespace DiCargoHubApi.Infrastructure.IoC;
public class IoC
{
	public static ILifetimeScope Container { private get; set; } = null!;
}
