﻿using System.Text.Json.Serialization;

namespace DiCargoHubApi.Infrastructure.Enums;
[JsonConverter(typeof(JsonStringEnumConverter<OfferStatus>))]
public enum OfferStatus
{
	Unknown,
	Pending,
	Accepted,
	Rejected
}
