﻿using System.Text.Json.Serialization;

namespace DiCargoHubApi.Infrastructure.Enums;
[JsonConverter(typeof(JsonStringEnumConverter<OrderStatus>))]
public enum OrderStatus
{
	Pending,
	Offered,
	InProgress,
	WaitingForComplete,
	Completed,
	Cancelled
}
