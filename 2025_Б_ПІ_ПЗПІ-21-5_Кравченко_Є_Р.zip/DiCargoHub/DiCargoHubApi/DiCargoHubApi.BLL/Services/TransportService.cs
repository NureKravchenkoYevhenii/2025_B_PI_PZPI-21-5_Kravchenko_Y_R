﻿using AutoMapper;
using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models.Transport;
using DiCargoHubApi.BLL.Infrastructure.Models;
using DiCargoHubApi.DAL.Contracts;
using DiCargoHubApi.Domain.Models;

namespace DiCargoHubApi.BLL.Services;
public class TransportService : ITransportService
{
	private readonly IUnitOfWork _uow;
	private readonly IRepository<Transport> _transports;
	private readonly IMapper _mapper;

	public TransportService(IUnitOfWork uow, IMapper mapper)
	{
		_uow = uow;
		_mapper = mapper;
		_transports = _uow.GetRepository<Transport>();
	}

	public async Task<TransportDto> AddAsync(Guid carrierId, CreateTransportDto dto)
	{
		var transport = _mapper.Map<Transport>(dto);
		transport.CarrierId = carrierId;

		await _transports.AddAsync(transport);
		await _uow.CommitAsync();

		return _mapper.Map<TransportDto>(transport);
	}

	public async Task<IEnumerable<TransportDto>> GetByCarrierAsync(Guid carrierId)
	{
		var list = await _transports.GetListAsync(t => t.CarrierId == carrierId);
		return _mapper.Map<List<TransportDto>>(list);
	}

	public async Task<TransportDto> GetByIdAsync(Guid transportId)
	{
		var transport = await _transports.GetByIdAsync(transportId)
			?? throw new KeyNotFoundException($"Transport {transportId} not found");

		return _mapper.Map<TransportDto>(transport);
	}

	public async Task<TransportDto> UpdateAsync(Guid transportId, UpdateTransportDto dto)
	{
		var transport = await _transports.GetByIdAsync(transportId)
			?? throw new KeyNotFoundException($"Transport {transportId} not found");

		_mapper.Map(dto, transport);

		_transports.Update(transport);
		await _uow.CommitAsync();

		return _mapper.Map<TransportDto>(transport);
	}

	public async Task DeleteAsync(Guid transportId)
	{
		var transport = await _transports.GetByIdAsync(transportId)
			?? throw new KeyNotFoundException($"Transport {transportId} not found");

		_transports.Remove(transport);
		await _uow.CommitAsync();
	}
}
