﻿using AutoMapper;
using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models;
using DiCargoHubApi.DAL.Contracts;
using DiCargoHubApi.Domain.Models;
using DiCargoHubApi.Infrastructure.Configs;
using DiCargoHubApi.Infrastructure.Enums;
using DiCargoHubApi.Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace DiCargoHubApi.BLL.Services;
public class AuthService : IAuthService
{
	private readonly AuthOptions _authOptions;
	private readonly IUnitOfWork _uow;
	private readonly IRepository<User> _users;
	private readonly IMapper _mapper;

	public AuthService(IUnitOfWork uow, IMapper mapper, AuthOptions authOptions)
	{
		_authOptions = authOptions;
		_mapper = mapper;
		_uow = uow;
		_users = uow.GetRepository<User>();
	}

	public async Task<UserDto> RegisterAsync(RegisterDto dto)
	{
		if (_users.Get(u => u.Login == dto.Login) != null)
		{
			throw new ArgumentException("Login already taken");
		}

		var salt = PasswordHelper.GenerateSalt();
		var hash = PasswordHelper.Hash(dto.Password, salt);
		var user = new User
		{
			Login = dto.Login,
			PasswordSalt = salt,
			PasswordHash = hash,
			Role = dto.Role,
			RegistrationDate = DateTime.UtcNow,
			UserProfile = new UserProfile()
			{
				FirstName = string.Empty,
				LastName = string.Empty,
				ProfilePicture = [],
				Address = string.Empty,
				PhoneNumber = string.Empty,
				Email = string.Empty
			}
		};
		_users.Add(user);
		await _uow.CommitAsync();

		return _mapper.Map<UserDto>(user);
	}

	public async Task<AuthTokenDto> LoginAsync(LoginDto dto)
	{
		var user = _users.Get(u => u.Login == dto.Login)
			?? throw new UnauthorizedAccessException("Invalid credentials");

		if (!PasswordHelper.Verify(dto.Password, user.PasswordSalt, user.PasswordHash))
		{
			throw new UnauthorizedAccessException("Invalid credentials");
		}

		var jwtToken = GenerateJwtToken(user.Id, user.Role);
		var refreshToken = await GenerateRefreshToken(user.Id);
		
		return new AuthTokenDto
		{
			Jwt = jwtToken,
			RefreshToken = refreshToken
		};
	}

	public async Task<AuthTokenDto> RefreshTokenAsync(Guid refreshToken)
	{
		var user = _users.GetAll()
			.Include(u => u.RefreshTokens)
			.FirstOrDefault(u => u.RefreshTokens.Any(rt =>
				rt.Token == refreshToken
				&& rt.ExpiresOn >= DateTime.UtcNow)
			) ?? throw new Exception("Недійсний токен оновлення");

		var jwtToken = GenerateJwtToken(user.Id, user.Role);
		var newRefreshToken = await GenerateRefreshToken(user.Id);

		return new AuthTokenDto
		{
			Jwt = jwtToken,
			RefreshToken = newRefreshToken
		};
	}

	protected string GenerateJwtToken(Guid userId, Role userRole)
	{
		var credentials = new SigningCredentials(
			key: _authOptions.PrivateKey,
			algorithm: SecurityAlgorithms.RsaSha256
		);

		var jwtToken = new JwtSecurityToken(
			_authOptions.Issuer,
			_authOptions.Audience,
			[
				new Claim("id", userId.ToString()),
				new Claim(ClaimTypes.Role, userRole.ToString()),
				new Claim("role", userRole.ToString()),
			],
			expires: DateTime.UtcNow.AddSeconds(_authOptions.TokenLifetime),
			signingCredentials: credentials);

		var tokenString = new JwtSecurityTokenHandler().WriteToken(jwtToken);

		return tokenString;
	}

	protected async Task<Guid> GenerateRefreshToken(Guid userId)
	{
		var user = _users.GetAll()
			.Include(u => u.RefreshTokens)
			.FirstOrDefault(u => u.Id == userId)
				?? throw new Exception("Користувача не знайдено");

		var refreshToken = new RefreshToken()
		{
			Token = Guid.NewGuid(),
			UserId = userId,
			ExpiresOn = DateTime.UtcNow
				.AddSeconds(_authOptions.RefreshTokenLifetime),
		};

		user.RefreshTokens.Clear();
		user.RefreshTokens.Add(refreshToken);

		await _uow.CommitAsync();

		return refreshToken.Token;
	}
}
