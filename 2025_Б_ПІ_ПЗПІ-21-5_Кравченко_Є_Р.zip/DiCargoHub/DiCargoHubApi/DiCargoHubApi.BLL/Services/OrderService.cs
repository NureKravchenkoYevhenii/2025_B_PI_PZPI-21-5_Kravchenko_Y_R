﻿using AutoMapper;
using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Extensions;
using DiCargoHubApi.BLL.Infrastructure.Filters;
using DiCargoHubApi.BLL.Infrastructure.Models.Order;
using DiCargoHubApi.DAL.Contracts;
using DiCargoHubApi.Domain.Models;
using DiCargoHubApi.Infrastructure.Enums;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.BLL.Services;
public class OrderService : IOrderService
{
	private readonly IUnitOfWork _uow;
	private readonly IRepository<Order> _orders;
	private readonly IRepository<User> _users;
	private readonly IMapper _mapper;

	public OrderService(IUnitOfWork uow, IMapper mapper)
	{
		_uow = uow;
		_mapper = mapper;
		_orders = _uow.GetRepository<Order>();
		_users = _uow.GetRepository<User>();
	}

	public async Task<OrderDto> CreateOrderAsync(Guid customerId, CreateOrderDto dto)
	{
		var order = _mapper.Map<Order>(dto);
		order.CustomerId = customerId;
		order.CreatedOn = DateTime.UtcNow;
		order.Status = OrderStatus.Pending;

		_orders.Add(order);
		await _uow.CommitAsync();

		return _mapper.Map<OrderDto>(order);
	}

	public async Task<OrderDto?> GetByIdAsync(Guid orderId)
	{
		var order = await _orders.GetByIdAsync(orderId)
			?? throw new Exception($"Order {orderId} not found");

		return _mapper.Map<OrderDto>(order);
	}

	public async Task<OrderDetailsDto> GetDetailsByIdAsync(Guid orderId)
	{
		var order = await _orders.GetAll()
			.Include(o => o.Customer)
			.ThenInclude(c => c.UserProfile)
			.FirstOrDefaultAsync(o => o.Id == orderId)
				?? throw new Exception("Order not found");

		var orderDetails = _mapper.Map<OrderDetailsDto>(order);
		await LoadOrderCarrierAsync(orderDetails);
		return orderDetails;
	}

	public async Task<IEnumerable<OrderDto>> SearchAsync(OrderFilter filter)
	{
		var query = _orders.GetAll().Filter(filter);
		var orders = await query.ToListAsync();

		return _mapper.Map<IEnumerable<OrderDto>>(orders);
	}

	public async Task UpdateStatusAsync(Guid orderId, string newStatus)
	{
		var order = await _orders.GetByIdAsync(orderId)
			?? throw new Exception($"Order {orderId} not found");

		if (!Enum.TryParse<OrderStatus>(newStatus, out var status))
			throw new ArgumentException($"Invalid status: {newStatus}");

		order.Status = status;
		_orders.Update(order);
		await _uow.CommitAsync();
	}

	public async Task UpdateOrderAsync(Guid orderId, UpdateOrderDto dto)
	{
		var order = await _orders.GetByIdAsync(orderId)
			?? throw new KeyNotFoundException($"Order {orderId} not found");

		_mapper.Map(dto, order);
		_orders.Update(order);
		await _uow.CommitAsync();
	}
	
	protected async Task LoadOrderCarrierAsync(OrderDetailsDto order)
	{
		var carrier = await _users.GetAll()
			.Include(u => u.UserProfile)
			.Where(u => u.Offers.Any(o => o.OrderId == order.Id && o.Status == OfferStatus.Accepted))
			.FirstOrDefaultAsync();
		if (carrier != null)
		{
			order.CarrierId = carrier.Id;
			order.CarrierName = $"{carrier.UserProfile.FirstName} {carrier.UserProfile.LastName}".Trim();
		}
	}
}
