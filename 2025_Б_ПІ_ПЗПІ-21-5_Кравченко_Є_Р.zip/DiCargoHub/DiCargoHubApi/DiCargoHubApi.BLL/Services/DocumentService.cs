﻿using AutoMapper;
using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models;
using DiCargoHubApi.DAL.Contracts;
using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.BLL.Services;
public class DocumentService : IDocumentService
{
	private readonly IUnitOfWork _uow;
	private readonly IRepository<Document> _documents;
	private readonly IRepository<Order> _orders;
	private readonly IMapper _mapper;

	public DocumentService(
		IUnitOfWork uow,
		IMapper mapper)
	{
		_uow = uow;
		_mapper = mapper;
		_documents = _uow.GetRepository<Document>();
		_orders = _uow.GetRepository<Order>();
	}

	public async Task<DocumentDto> UploadAsync(Guid orderId, UploadDocumentDto dto)
	{
		var orderExists = await _orders.GetAll()
			.AnyAsync(o => o.Id == orderId);
		if (!orderExists)
			throw new KeyNotFoundException($"Order {orderId} not found");

		var document = _mapper.Map<Document>(dto);
		document.OrderId = orderId;
		document.SignedByCustomer = false;
		document.SignedByCarrier = false;

		await _documents.AddAsync(document);
		await _uow.CommitAsync();

		return _mapper.Map<DocumentDto>(document);
	}

	public async Task SignAsync(Guid documentId, Guid signerUserId)
	{
		var document = await _documents.GetByIdAsync(documentId)
			?? throw new KeyNotFoundException($"Document {documentId} not found");

		var order = await _orders.GetByIdAsync(document.OrderId)
			?? throw new KeyNotFoundException($"Order {document.OrderId} not found");

		if (order.CustomerId == signerUserId)
			document.SignedByCustomer = true;
		else
			document.SignedByCarrier = true;

		_documents.Update(document);
		await _uow.CommitAsync();
	}

	public async Task<DocumentDto> GetByIdAsync(Guid id)
	{
		var document = await _documents.GetByIdAsync(id)
			?? throw new KeyNotFoundException($"Document not found");

		return _mapper.Map<DocumentDto>(document);
	}

	public async Task<IEnumerable<DocumentDto>> GetByOrderAsync(Guid orderId)
	{
		var orderExists = await _orders.GetAll()
			.AnyAsync(o => o.Id == orderId);
		if (!orderExists)
			throw new KeyNotFoundException($"Order {orderId} not found");

		var list = await _documents.GetListAsync(d => d.OrderId == orderId);

		return _mapper.Map<IEnumerable<DocumentDto>>(list);
	}
}
