﻿using AutoMapper;
using DiCargoHubApi.BLL.Infrastructure.Models;
using DiCargoHubApi.Domain.Models;

namespace DiCargoHubApi.BLL.Infrastructure.Mapper;
public class ReviewProfile : Profile
{
	public ReviewProfile()
	{
		CreateMap<CreateReviewDto, Review>();

		CreateMap<Review, ReviewDto>();
	}
}
