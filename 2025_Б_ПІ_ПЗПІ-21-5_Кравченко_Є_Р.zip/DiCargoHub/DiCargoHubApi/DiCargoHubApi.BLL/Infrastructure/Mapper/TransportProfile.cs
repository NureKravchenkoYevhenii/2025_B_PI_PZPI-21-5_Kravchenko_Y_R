﻿using AutoMapper;
using DiCargoHubApi.BLL.Infrastructure.Models.Transport;
using DiCargoHubApi.BLL.Infrastructure.Models;
using DiCargoHubApi.Domain.Models;
using DiCargoHubApi.Infrastructure.Enums;

namespace DiCargoHubApi.BLL.Infrastructure.Mapper;
public class TransportProfile : Profile
{
	public TransportProfile()
	{
		CreateMap<CreateTransportDto, Transport>()
			.ForMember(dest => dest.Type,
				opt => opt.MapFrom(src => Enum.Parse<TransportType>(src.Type)));

		CreateMap<UpdateTransportDto, Transport>()
			.ForMember(dest => dest.Type,
				opt => opt.MapFrom(src => Enum.Parse<TransportType>(src.Type)));

		CreateMap<Transport, TransportDto>()
			.ForMember(dest => dest.Type,
				opt => opt.MapFrom(src => src.Type.ToString()));
	}
}
