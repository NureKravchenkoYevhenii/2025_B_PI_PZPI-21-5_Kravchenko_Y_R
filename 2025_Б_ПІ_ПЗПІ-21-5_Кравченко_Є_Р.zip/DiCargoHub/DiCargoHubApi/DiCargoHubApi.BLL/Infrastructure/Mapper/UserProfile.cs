﻿using AutoMapper;
using DiCargoHubApi.BLL.Infrastructure.Models;
using DiCargoHubApi.Domain.Models;

namespace DiCargoHubApi.BLL.Infrastructure.Mapper;
public class UserProfile : Profile
{
	public UserProfile()
	{
		CreateMap<User, UserDto>()
			.ForMember(dst => dst.RegistrationDate,
				opt => opt.MapFrom(src => src.RegistrationDate.ToLocalTime()));
	}
}
