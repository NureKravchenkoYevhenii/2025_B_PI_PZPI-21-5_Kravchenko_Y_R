﻿using AutoMapper;
using DiCargoHubApi.BLL.Infrastructure.Models;
using DiCargoHubApi.Domain.Models;

namespace DiCargoHubApi.BLL.Infrastructure.Mapper;
public class DocumentProfile : Profile
{
	public DocumentProfile()
	{
		CreateMap<UploadDocumentDto, Document>();
		
		CreateMap<Document, DocumentDto>();
	}
}
