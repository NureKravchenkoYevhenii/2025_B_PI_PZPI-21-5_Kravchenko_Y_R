﻿using AutoMapper;
using DiCargoHubApi.BLL.Infrastructure.Models.Offer;
using DiCargoHubApi.Domain.Models;

namespace DiCargoHubApi.BLL.Infrastructure.Mapper;
public class OfferProfile : Profile
{
	public OfferProfile()
	{
		CreateMap<CreateOfferDto, Offer>();

		CreateMap<Offer, OfferDto>()
			.ForMember(dest => dest.CarrierName, opt => {
				opt.PreCondition(src => src.Carrier != null && src.Carrier?.UserProfile != null);
				opt.MapFrom(src =>
					$"{src.Carrier.UserProfile.FirstName} {src.Carrier.UserProfile.LastName}".Trim()
				);
			})
			.ForMember(dest => dest.OrderDescription, opt =>
			{
				opt.PreCondition(src => src.Order != null);
				opt.MapFrom(src => src.Order.CargoDescription);
			})
			.ForMember(dest => dest.Status,
				opt => opt.MapFrom(src => src.Status.ToString()));
	}
}
