﻿using DiCargoHubApi.Domain.Models;

namespace DiCargoHubApi.BLL.Infrastructure.Filters;
public abstract class BaseFilter<T>
	where T : BaseEntity
{
	public PagingModel? PagingModel { get; set; }

	public virtual IQueryable<T> Apply(IQueryable<T> query)
	{
		return query;
	}
}
