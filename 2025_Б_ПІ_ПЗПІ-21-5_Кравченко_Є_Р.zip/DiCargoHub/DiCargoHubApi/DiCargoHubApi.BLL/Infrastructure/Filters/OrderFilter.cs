﻿using DiCargoHubApi.BLL.Infrastructure.Extensions;
using DiCargoHubApi.Domain.Models;
using DiCargoHubApi.Infrastructure.Enums;

namespace DiCargoHubApi.BLL.Infrastructure.Filters;
public class OrderFilter : BaseFilter<Order>
{
	public Guid? CustomerId { get; set; }
	
	public string? Origin { get; set; }
	
	public string? Destination { get; set; }
	
	public string? Status { get; set; }

	public override IQueryable<Order> Apply(IQueryable<Order> query)
	{
		if (CustomerId.HasValue)
			query = query.Where(o => o.CustomerId == CustomerId.Value);

		if (!string.IsNullOrEmpty(Origin))
			query = query.Where(o => o.Origin.Contains(Origin));

		if (!string.IsNullOrEmpty(Destination))
			query = query.Where(o => o.Destination.Contains(Destination));

		if (!string.IsNullOrEmpty(Status)
			&& Enum.TryParse<OrderStatus>(Status, out var status))
		{
			query = query.Where(o => o.Status == status);
		}

		var ordered = query.OrderBy(o => o.CreatedOn)
			.GetPage(PagingModel);

		return ordered;
	}
}
