﻿namespace DiCargoHubApi.BLL.Infrastructure.Models.Order;
public class OrderDto
{
	public Guid Id { get; set; }
	
	public Guid CustomerId { get; set; }
	
	public DateTime CreatedOn { get; set; }
	
	public string CargoDescription { get; set; } = null!;
	
	public string Origin { get; set; } = null!;
	
	public string Destination { get; set; } = null!;
	
	public string Status { get; set; } = null!;
	
	public decimal Price { get; set; }
}
