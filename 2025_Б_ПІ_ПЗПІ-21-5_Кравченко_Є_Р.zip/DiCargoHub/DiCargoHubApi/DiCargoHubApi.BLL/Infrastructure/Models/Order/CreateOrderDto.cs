﻿namespace DiCargoHubApi.BLL.Infrastructure.Models.Order;
public class CreateOrderDto
{
	public string CargoDescription { get; set; } = null!;
	
	public string Origin { get; set; } = null!;
	
	public string Destination { get; set; } = null!;
	
	public decimal Price { get; set; }
}
