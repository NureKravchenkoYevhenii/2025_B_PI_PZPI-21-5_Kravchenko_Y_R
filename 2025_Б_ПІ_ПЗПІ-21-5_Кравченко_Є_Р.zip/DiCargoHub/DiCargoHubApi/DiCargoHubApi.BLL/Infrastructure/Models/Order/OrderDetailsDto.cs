﻿namespace DiCargoHubApi.BLL.Infrastructure.Models.Order;

public class OrderDetailsDto
{
	public Guid Id { get; set; }

	public Guid CustomerId { get; set; }

	public string? CustomerName { get; set; }

	public Guid? CarrierId { get; set; }

	public string? CarrierName { get; set; }

	public string Status { get; set; } = null!;
}
