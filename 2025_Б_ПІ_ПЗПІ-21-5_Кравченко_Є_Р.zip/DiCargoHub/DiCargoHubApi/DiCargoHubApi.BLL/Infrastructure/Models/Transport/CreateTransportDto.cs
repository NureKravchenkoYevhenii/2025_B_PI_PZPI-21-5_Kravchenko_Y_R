﻿namespace DiCargoHubApi.BLL.Infrastructure.Models;
public class CreateTransportDto
{
	public string LicensePlate { get; set; } = null!;
	
	public double Capacity { get; set; }
	
	public string Type { get; set; } = null!;
}
