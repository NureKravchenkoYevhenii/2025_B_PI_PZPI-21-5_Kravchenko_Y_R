﻿namespace DiCargoHubApi.BLL.Infrastructure.Models.Transport;
public class UpdateTransportDto
{
	public string LicensePlate { get; set; } = null!;
	
	public double Capacity { get; set; }
	
	public string Type { get; set; } = null!;
}
