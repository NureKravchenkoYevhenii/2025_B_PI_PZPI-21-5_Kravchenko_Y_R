﻿using DiCargoHubApi.Infrastructure.Enums;

namespace DiCargoHubApi.BLL.Infrastructure.Models;
public class RegisterDto
{
	public string Login { get; set; } = string.Empty;

	public string Password { get; set; } = string.Empty;

	public Role Role { get; set; }
}
