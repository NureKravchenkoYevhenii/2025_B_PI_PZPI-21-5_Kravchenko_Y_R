﻿using DiCargoHubApi.Infrastructure.Enums;

namespace DiCargoHubApi.BLL.Infrastructure.Models;
public class UserDto
{
	public Guid Id { get; set; }

	public string Login { get; set; } = string.Empty;

	public Role Role { get; set; }

	public DateTime RegistrationDate { get; set; }
}
