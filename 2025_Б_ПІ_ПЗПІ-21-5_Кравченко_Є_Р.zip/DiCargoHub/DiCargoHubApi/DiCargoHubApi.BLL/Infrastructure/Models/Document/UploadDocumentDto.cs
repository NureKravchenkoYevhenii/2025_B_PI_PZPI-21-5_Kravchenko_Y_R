﻿namespace DiCargoHubApi.BLL.Infrastructure.Models;
public class UploadDocumentDto
{
	public string Name { get; set; } = null!;

	public string IpfsHash { get; set; } = null!;
}
