﻿namespace DiCargoHubApi.BLL.Infrastructure.Models;
public class DocumentDto
{
	public Guid Id { get; set; }
	
	public string Name { get; set; } = null!;
	
	public string IpfsHash { get; set; } = null!;
	
	public bool SignedByCustomer { get; set; }
	
	public bool SignedByCarrier { get; set; }
	
	public Guid OrderId { get; set; }
}
