﻿namespace DiCargoHubApi.BLL.Infrastructure.Models.Contract;
public class CreateContractDto
{
	public Guid OfferId { get; set; }
}
