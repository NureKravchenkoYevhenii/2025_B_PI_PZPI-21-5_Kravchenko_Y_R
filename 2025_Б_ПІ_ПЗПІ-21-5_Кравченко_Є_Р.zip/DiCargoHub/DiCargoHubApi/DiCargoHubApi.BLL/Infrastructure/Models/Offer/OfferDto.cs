﻿namespace DiCargoHubApi.BLL.Infrastructure.Models.Offer;
public class OfferDto
{
	public Guid Id { get; set; }
	
	public Guid CarrierId { get; set; }

	public string? CarrierName { get; set; }

	public Guid OrderId { get; set; }

	public string? OrderDescription { get; set; }

	public string Status { get; set; } = null!;
	
	public string Message { get; set; } = null!;
}
