﻿namespace DiCargoHubApi.BLL.Infrastructure.Models.Offer;
public class CreateOfferDto
{
	public Guid OrderId { get; set; }

	public string Message { get; set; } = null!;
}
