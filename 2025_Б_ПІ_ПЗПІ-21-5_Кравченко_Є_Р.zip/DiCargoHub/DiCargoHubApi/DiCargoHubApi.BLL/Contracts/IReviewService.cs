﻿using DiCargoHubApi.BLL.Infrastructure.Models;

namespace DiCargoHubApi.BLL.Contracts;
public interface IReviewService
{
	Task<ReviewDto> AddReviewAsync(
		Guid orderId,
		Guid reviewerId,
		CreateReviewDto dto
	);

	Task<decimal> GetAverageRatingAsync(Guid ratedUserId);
}
