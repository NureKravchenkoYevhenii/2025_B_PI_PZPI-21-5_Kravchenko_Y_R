﻿using DiCargoHubApi.BLL.Infrastructure.Models.Transport;
using DiCargoHubApi.BLL.Infrastructure.Models;

namespace DiCargoHubApi.BLL.Contracts;
public interface ITransportService
{
	Task<TransportDto> AddAsync(Guid carrierId, CreateTransportDto dto);

	Task<IEnumerable<TransportDto>> GetByCarrierAsync(Guid carrierId);

	Task<TransportDto> UpdateAsync(Guid transportId, UpdateTransportDto dto);

	Task<TransportDto> GetByIdAsync(Guid transportId);

	Task DeleteAsync(Guid transportId);
}
