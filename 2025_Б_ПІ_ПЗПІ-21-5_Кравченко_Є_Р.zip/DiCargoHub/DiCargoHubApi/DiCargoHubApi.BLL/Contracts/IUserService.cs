﻿using DiCargoHubApi.BLL.Infrastructure.Models;

namespace DiCargoHubApi.BLL.Contracts;
public interface IUserService
{
	Task<UserProfileDto> GetProfileAsync(Guid userId);

	Task UpdateProfileAsync(Guid userId, UpdateProfileDto dto);
}
