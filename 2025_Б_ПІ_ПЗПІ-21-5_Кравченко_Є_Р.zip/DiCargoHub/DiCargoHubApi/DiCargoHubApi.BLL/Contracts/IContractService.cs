﻿using DiCargoHubApi.BLL.Infrastructure.Models.Contract;

namespace DiCargoHubApi.BLL.Contracts;
public interface IContractService
{
	Task<ContractDto> CreateFromOfferAsync(CreateContractDto dto);

	Task SignAsync(Guid contractId, Guid signerUserId);

	Task<ContractDto> GetByIdAsync(Guid contractId);
}
