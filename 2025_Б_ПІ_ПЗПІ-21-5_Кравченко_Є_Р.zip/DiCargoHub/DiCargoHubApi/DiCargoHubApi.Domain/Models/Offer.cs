﻿using DiCargoHubApi.Infrastructure.Enums;
using Newtonsoft.Json;

namespace DiCargoHubApi.Domain.Models;
public class Offer : BaseEntity
{
	public Guid CarrierId { get; set; }

	public Guid OrderId { get; set; }

	public OfferStatus Status { get; set; }

	public string Message { get; set; }

	#region Relations

	[JsonIgnore]
	public User Carrier { get; set; }

	[JsonIgnore]
	public Order Order { get; set; }

	#endregion
}
