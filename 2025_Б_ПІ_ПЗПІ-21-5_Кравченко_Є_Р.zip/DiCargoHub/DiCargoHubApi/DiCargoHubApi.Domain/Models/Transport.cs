﻿using DiCargoHubApi.Infrastructure.Enums;
using Newtonsoft.Json;

namespace DiCargoHubApi.Domain.Models;
public class Transport : BaseEntity
{
	public TransportType Type { get; set; }

	public string LicensePlate { get; set; }

	public double Capacity { get; set; }

	public Guid CarrierId { get; set; }

	#region Relations

	[JsonIgnore]
	public User Carrier { get; set; }

	#endregion
}
