﻿using DiCargoHubApi.Infrastructure.Enums;
using Newtonsoft.Json;

namespace DiCargoHubApi.Domain.Models;
public class Order : BaseEntity
{
	public Guid CustomerId { get; set; }

	public DateTime CreatedOn { get; set; }

	public string CargoDescription { get; set; }

	public string Origin { get; set; }

	public string Destination { get; set; }

	public OrderStatus Status { get; set; }

	public decimal Price { get; set; }

	#region Relations

	[JsonIgnore]
	public User Customer { get; set; }

	[JsonIgnore]
	public ICollection<Offer> Offers { get; set; }

	[JsonIgnore]
	public ICollection<Document> Documents { get; set; }

	[JsonIgnore]
	public ICollection<Contract> Contracts { get; set; }

	[JsonIgnore]
	public ICollection<Review> Reviews { get; set; }

	#endregion
}