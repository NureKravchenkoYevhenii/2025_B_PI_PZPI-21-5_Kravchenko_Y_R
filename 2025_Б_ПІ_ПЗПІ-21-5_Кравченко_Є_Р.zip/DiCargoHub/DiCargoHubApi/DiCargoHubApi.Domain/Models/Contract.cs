﻿using DiCargoHubApi.Infrastructure.Enums;
using Newtonsoft.Json;

namespace DiCargoHubApi.Domain.Models;
public class Contract : BaseEntity
{
	public string IpfsHash { get; set; }

	public bool SignedByCustomer { get; set; }

	public bool SignedByCarrier { get; set; }

	public ContractStatus Status { get; set; }

	public Guid OrderId { get; set; }

	public Guid CustomerId { get; set; }

	public Guid CarrierId { get; set; }

	#region Relations

	[JsonIgnore]
	public Order Order { get; set; }

	[JsonIgnore]
	public User Customer { get; set; }

	[JsonIgnore]
	public User Carrier { get; set; }

	#endregion
}
