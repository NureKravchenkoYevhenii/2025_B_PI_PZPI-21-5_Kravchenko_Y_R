﻿namespace DiCargoHubApi.Domain.Models;
public class Review : BaseEntity
{
	public int Score { get; set; }

	public string Comments { get; set; }

	public Guid OrderId { get; set; }

	public Guid RatedUserId { get; set; }

	public Guid ReviewerId { get; set; }

	#region Relations
	
	public Order Order { get; set; }

	public User RatedUser { get; set; }

	public User Reviewer { get; set; }

	#endregion
}
