﻿using DiCargoHubApi.DAL.Contracts;
using DiCargoHubApi.DAL.DbContexts;
using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace DiCargoHubApi.DAL.Repositories;
public class Repository<TEntity> : IRepository<TEntity>
	where TEntity : BaseEntity
{
	private readonly DiCargoHubApiDbContext _dbContext;
	private readonly DbSet<TEntity> _dbSet;

	public Repository(DiCargoHubApiDbContext dbContext)
	{
		_dbContext = dbContext;
		_dbSet = _dbContext.Set<TEntity>();
	}

	public virtual void Add(TEntity entity)
	{
		_dbSet.Add(entity);
	}

	public virtual async Task AddAsync(TEntity entity)
	{
		await _dbSet.AddAsync(entity);
	}

	public virtual TEntity? Get(Expression<Func<TEntity, bool>> predicate)
	{
		return _dbSet.FirstOrDefault(predicate);
	}

	public virtual IQueryable<TEntity> GetAll()
	{
		return _dbSet.AsQueryable();
	}

	public virtual TEntity? GetById(Guid id)
	{
		return _dbSet.Find(id);
	}

	public async virtual Task<TEntity?> GetByIdAsync(Guid id)
	{
		return await _dbSet.FindAsync(id);
	}

	public virtual IQueryable<TEntity> GetList(Expression<Func<TEntity, bool>> predicate)
	{
		return _dbSet.Where(predicate);
	}

	public async Task<List<TEntity>> GetListAsync(Expression<Func<TEntity, bool>> predicate)
	{
		return await _dbSet
			.Where(predicate)
			.ToListAsync();
	}

	public virtual void Remove(TEntity entity)
	{
		_dbSet.Remove(entity);
	}

	public virtual void Update(TEntity entity)
	{
		_dbSet.Update(entity);
	}

	public virtual void UpdateRange(params TEntity[] entities)
	{
		_dbSet.UpdateRange(entities);
	}
}
