﻿using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.DAL.EntityConfigurations;
public class ReviewConfiguration : IEntityTypeConfiguration<Review>
{
	public void Configure(EntityTypeBuilder<Review> builder)
	{
		builder.ToTable("Reviews");
		builder.HasKey(r => r.Id);

		builder.Property(r => r.Score)
			.IsRequired();

		builder.Property(r => r.Comments)
			.HasMaxLength(1000);

		builder.HasOne(r => r.Order)
			.WithMany(o => o.Reviews)
			.HasForeignKey(r => r.OrderId)
			.OnDelete(DeleteBehavior.Cascade);

		builder.HasOne(r => r.RatedUser)
			.WithMany(u => u.ReceivedReviews)
			.HasForeignKey(r => r.RatedUserId)
			.OnDelete(DeleteBehavior.Restrict);

		builder.HasOne(r => r.Reviewer)
			.WithMany(u => u.GivenReviews)
			.HasForeignKey(r => r.ReviewerId)
			.OnDelete(DeleteBehavior.Restrict);
	}
}
