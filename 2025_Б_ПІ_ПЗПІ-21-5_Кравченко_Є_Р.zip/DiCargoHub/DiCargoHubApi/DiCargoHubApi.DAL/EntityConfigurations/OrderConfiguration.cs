﻿using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.DAL.EntityConfigurations;
public class OrderConfiguration : IEntityTypeConfiguration<Order>
{
	public void Configure(EntityTypeBuilder<Order> builder)
	{
		builder.ToTable("Orders");
		builder.HasKey(o => o.Id);

		builder.Property(o => o.CreatedOn).IsRequired();
		builder.Property(o => o.CargoDescription).IsRequired().HasMaxLength(500);
		builder.Property(o => o.Origin).IsRequired().HasMaxLength(200);
		builder.Property(o => o.Destination).IsRequired().HasMaxLength(200);
		builder.Property(o => o.Status).IsRequired();
		builder.Property(o => o.Price).HasColumnType("decimal(18,2)");

		builder.HasOne(o => o.Customer)
			.WithMany(u => u.Orders)
			.HasForeignKey(o => o.CustomerId)
			.OnDelete(DeleteBehavior.Cascade);
	}
}
