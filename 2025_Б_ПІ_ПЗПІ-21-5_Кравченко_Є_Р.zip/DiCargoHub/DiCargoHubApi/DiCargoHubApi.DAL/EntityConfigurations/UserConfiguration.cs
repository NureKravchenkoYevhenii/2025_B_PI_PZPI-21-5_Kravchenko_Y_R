﻿using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.DAL.EntityConfigurations;
public class UserConfiguration : IEntityTypeConfiguration<User>
{
	public void Configure(EntityTypeBuilder<User> builder)
	{
		builder.ToTable("Users");
		builder.HasKey(u => u.Id);

		builder.Property(u => u.Login).IsRequired().HasMaxLength(100);
		builder.Property(u => u.PasswordHash).IsRequired().HasMaxLength(255);
		builder.Property(u => u.PasswordSalt).IsRequired().HasMaxLength(255);
		builder.Property(u => u.RegistrationDate).IsRequired();
		builder.Property(u => u.Role).IsRequired();
	}
}
