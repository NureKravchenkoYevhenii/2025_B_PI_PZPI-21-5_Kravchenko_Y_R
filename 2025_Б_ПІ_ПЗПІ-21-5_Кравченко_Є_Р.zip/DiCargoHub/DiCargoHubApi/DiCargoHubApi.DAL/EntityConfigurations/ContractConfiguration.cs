﻿using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DiCargoHubApi.DAL.EntityConfigurations;

public class ContractConfiguration : IEntityTypeConfiguration<Contract>
{
	public void Configure(EntityTypeBuilder<Contract> builder)
	{
		builder.ToTable("Contracts");
		builder.HasKey(c => c.Id);

		builder.Property(c => c.IpfsHash).IsRequired().HasMaxLength(100);
		builder.Property(c => c.SignedByCustomer).IsRequired();
		builder.Property(c => c.SignedByCarrier).IsRequired();
		builder.Property(c => c.Status).IsRequired();

		builder.HasOne(c => c.Order)
			.WithMany(o => o.Contracts)
			.HasForeignKey(c => c.OrderId)
			.OnDelete(DeleteBehavior.Cascade);

		builder.HasOne(c => c.Customer)
			.WithMany(u => u.CustomerContracts)
			.HasForeignKey(c => c.CustomerId)
			.OnDelete(DeleteBehavior.Restrict);

		builder.HasOne(c => c.Carrier)
			.WithMany(u => u.CarrierContracts)
			.HasForeignKey(c => c.CarrierId)
			.OnDelete(DeleteBehavior.Restrict);
	}
}
