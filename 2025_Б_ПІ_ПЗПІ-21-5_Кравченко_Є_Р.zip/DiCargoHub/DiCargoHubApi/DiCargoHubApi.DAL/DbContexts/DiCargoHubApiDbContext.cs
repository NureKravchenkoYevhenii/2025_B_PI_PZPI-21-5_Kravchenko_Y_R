﻿using DiCargoHubApi.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace DiCargoHubApi.DAL.DbContexts;
public class DiCargoHubApiDbContext : DbContext
{
	public DbSet<User> Users { get; set; }

	public DbSet<UserProfile> UserProfiles { get; set; }

	public DbSet<RefreshToken> RefreshTokens { get; set; }

	public DbSet<Transport> Transports { get; set; }

	public DbSet<Order> Orders { get; set; }

	public DbSet<Offer> Offers { get; set; }

	public DbSet<Document> Documents { get; set; }

	public DbSet<Contract> Contracts { get; set; }

	public DiCargoHubApiDbContext(DbContextOptions options) : base(options) { }

	protected override void OnModelCreating(ModelBuilder modelBuilder)
	{
		base.OnModelCreating(modelBuilder);

		modelBuilder.ApplyConfigurationsFromAssembly(
			typeof(DiCargoHubApiDbContext).Assembly
		);
	}
}
