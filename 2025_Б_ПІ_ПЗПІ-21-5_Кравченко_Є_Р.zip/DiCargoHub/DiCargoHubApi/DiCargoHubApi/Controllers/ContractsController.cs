﻿using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models.Contract;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace DiCargoHubApi.Controllers;
[Area("contracts")]
[Route("api/[area]")]
[ApiController]
public class ContractsController : ControllerBase
{
	private readonly IContractService _contractService;

	public ContractsController(IContractService contractService)
	{
		_contractService = contractService;
	}

	[HttpPost("create")]
	[ProducesResponseType(typeof(ContractDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Create([FromBody] CreateContractDto createDto)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		var contract = await _contractService.CreateFromOfferAsync(createDto);
		return Ok(contract);
	}

	[HttpPost("{id}/sign")]
	[ProducesResponseType((int)HttpStatusCode.NoContent)]
	public async Task<IActionResult> Sign(
		[FromRoute] Guid id,
		[FromHeader(Name = "X-Signer-UserId")] Guid signerUserId
	)
	{
		await _contractService.SignAsync(id, signerUserId);
		return NoContent();
	}

	[HttpGet("{id}")]
	[ProducesResponseType(typeof(ContractDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetById([FromRoute] Guid id)
	{
		var contract = await _contractService.GetByIdAsync(id);
		return Ok(contract);
	}
}
