﻿using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models;
using DiCargoHubApi.BLL.Infrastructure.Models.Transport;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace DiCargoHubApi.Controllers;
[Area("transports")]
[Route("api/[area]")]
[ApiController]
public class TransportsController : ControllerBase
{
	private readonly ITransportService _transportService;

	public TransportsController(ITransportService transportService)
	{
		_transportService = transportService;
	}

	[HttpPost("create")]
	[ProducesResponseType(typeof(TransportDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Create(
		[FromHeader(Name = "X-Carrier-UserId")] Guid carrierId,
		[FromBody] CreateTransportDto dto
	)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		var transport = await _transportService.AddAsync(carrierId, dto);
		return Ok(transport);
	}

	[HttpGet("carrier/{carrierId}")]
	[ProducesResponseType(typeof(IEnumerable<TransportDto>), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetByCarrier([FromRoute] Guid carrierId)
	{
		var list = await _transportService.GetByCarrierAsync(carrierId);
		return Ok(list);
	}

	[HttpGet("{id}")]
	[ProducesResponseType(typeof(TransportDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetById([FromRoute] Guid id)
	{
		var transport = await _transportService.GetByIdAsync(id);
		return Ok(transport);
	}

	[HttpPut("{id}")]
	[ProducesResponseType(typeof(TransportDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Update(
		[FromRoute] Guid id,
		[FromBody] UpdateTransportDto dto
	)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		var updated = await _transportService.UpdateAsync(id, dto);
		return Ok(updated);
	}

	[HttpDelete("{id}")]
	[ProducesResponseType((int)HttpStatusCode.NoContent)]
	public async Task<IActionResult> Delete([FromRoute] Guid id)
	{
		await _transportService.DeleteAsync(id);
		return NoContent();
	}
}
