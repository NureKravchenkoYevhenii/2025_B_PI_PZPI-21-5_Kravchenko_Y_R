﻿using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models.Offer;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace DiCargoHubApi.Controllers;
[Area("offers")]
[Route("api/[area]")]
[ApiController]
public class OffersController : ControllerBase
{
	private readonly IOfferService _offerService;

	public OffersController(IOfferService offerService)
	{
		_offerService = offerService;
	}

	[HttpPost("create")]
	[ProducesResponseType(typeof(OfferDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Create(
		[FromHeader(Name = "X-Carrier-UserId")] Guid carrierId,
		[FromBody] CreateOfferDto dto
	)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		var offer = await _offerService.CreateOfferAsync(carrierId, dto);
		return Ok(offer);
	}

	[HttpGet("order/{orderId}")]
	[ProducesResponseType(typeof(IEnumerable<OfferDto>), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetByOrder([FromRoute] Guid orderId)
	{
		var list = await _offerService.GetByOrderAsync(orderId);
		return Ok(list);
	}

	[HttpPost("{id}/accept")]
	[ProducesResponseType((int)HttpStatusCode.NoContent)]
	public async Task<IActionResult> Accept([FromRoute] Guid id)
	{
		await _offerService.AcceptOfferAsync(id);
		return NoContent();
	}

	[HttpGet("carrier/{carrierId}")]
	[ProducesResponseType(typeof(IEnumerable<OfferDto>), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> GetPendingByCarrier([FromRoute] Guid carrierId)
	{
		var list = await _offerService.GetPendingByCarrierAsync(carrierId);
		return Ok(list);
	}

	[HttpDelete("{id}")]
	[ProducesResponseType((int)HttpStatusCode.NoContent)]
	public async Task<IActionResult> Delete(
		[FromHeader(Name = "X-Carrier-UserId")] Guid carrierId,
		[FromRoute] Guid id
	)
	{
		await _offerService.DeleteOfferAsync(carrierId, id);
		return NoContent();
	}
}
