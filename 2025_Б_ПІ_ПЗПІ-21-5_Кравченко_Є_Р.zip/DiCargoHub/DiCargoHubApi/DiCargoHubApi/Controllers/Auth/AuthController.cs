﻿using DiCargoHubApi.BLL.Contracts;
using DiCargoHubApi.BLL.Infrastructure.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace DiCargoHubApi.Controllers.Auth;
[Area("auth")]
[Route("api/[area]")]
[ApiController]
public class AuthController : ControllerBase
{
	private readonly IAuthService _authService;

	public AuthController(IAuthService authService)
	{
		_authService = authService;
	}

	[HttpPost("login")]
	[ProducesResponseType(typeof(AuthTokenDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		var authToken = await _authService.LoginAsync(loginDto);

		return Ok(authToken);
	}

	[HttpGet("refresh")]
	[ProducesResponseType(typeof(AuthTokenDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Refresh([FromHeader] string refreshTokenString)
	{
		var refreshToken = Guid.Parse(refreshTokenString);
		var authToken = await _authService.RefreshTokenAsync(refreshToken);

		return Ok(authToken);
	}

	[HttpPost("register")]
	[ProducesResponseType(typeof(UserDto), (int)HttpStatusCode.OK)]
	public async Task<IActionResult> Register([FromBody] RegisterDto registerDto)
	{
		if (!ModelState.IsValid)
			return BadRequest(ModelState);

		var user = await _authService.RegisterAsync(registerDto);

		return Ok(user);
	}
}
