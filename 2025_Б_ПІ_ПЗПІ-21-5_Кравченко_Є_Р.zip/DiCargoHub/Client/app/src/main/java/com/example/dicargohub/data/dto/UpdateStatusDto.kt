package com.example.dicargohub.data.dto

import com.example.dicargohub.domain.OrderStatus

data class UpdateStatusDto(
    val status: OrderStatus
)