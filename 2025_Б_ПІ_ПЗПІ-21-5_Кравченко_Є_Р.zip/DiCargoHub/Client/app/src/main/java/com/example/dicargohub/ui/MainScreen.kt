package com.example.dicargohub.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.dicargohub.ui.auth.AuthStateHolder
import com.example.dicargohub.ui.components.BottomNavBar

@Composable
fun MainScreen(
    navController: NavHostController = rememberNavController(),
    authStateHolder: AuthStateHolder = hiltViewModel()
) {
    val isAuthenticated by authStateHolder.isAuthenticated.collectAsState()

    LaunchedEffect(isAuthenticated) {
        if (!isAuthenticated) {
            navController.navigate(NavRoutes.LOGIN) {
                popUpTo(0) { inclusive = true }
            }
        }
    }

    Scaffold(
        bottomBar = {
            if (isAuthenticated) {
                BottomNavBar(
                    navController = navController,
                    authStateHolder = authStateHolder
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AppNavGraph(
                navController = navController,
                authStateHolder = authStateHolder
            )
        }
    }
} 