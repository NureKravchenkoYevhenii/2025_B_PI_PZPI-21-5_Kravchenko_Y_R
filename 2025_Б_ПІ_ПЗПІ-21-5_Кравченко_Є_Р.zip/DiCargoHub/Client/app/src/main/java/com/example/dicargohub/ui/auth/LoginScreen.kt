package com.example.dicargohub.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.dicargohub.domain.Role
import com.example.dicargohub.ui.NavRoutes
import com.example.dicargohub.ui.components.CommonTextField

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    vm: AuthViewModel,
    navController: NavController,
    authStateHolder: AuthStateHolder,
    onDone: (String) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val state by vm.state.collectAsState()

    var login by remember { mutableStateOf("") }
    var pwd by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Scaffold { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(32.dp))
                
                Text(
                    text = "Ласкаво просимо до DiCargoHub",
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center
                )
                
                Text(
                    text = "Увійдіть до свого облікового запису",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Spacer(modifier = Modifier.height(32.dp))

                CommonTextField(
                    value = login,
                    onValueChange = { login = it },
                    label = "Логін",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth()
                )

                CommonTextField(
                    value = pwd,
                    onValueChange = { pwd = it },
                    label = "Пароль",
                    visualTransformation = if (passwordVisible)
                        VisualTransformation.None
                    else
                        PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible)
                                    Icons.Default.VisibilityOff
                                else
                                    Icons.Default.Visibility,
                                contentDescription = if (passwordVisible) "Приховати пароль" else "Показати пароль"
                            )
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        vm.login(login.trim(), pwd)
                        focusManager.clearFocus()
                    },
                    enabled = login.isNotBlank() && pwd.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text(
                        "Увійти",
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                TextButton(
                    onClick = { navController.navigate(NavRoutes.REGISTRATION) }
                ) {
                    Text(
                        "або зареєструйте новий",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            if (state is AuthState.Loading) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            when (state) {
                is AuthState.LoggedIn -> LaunchedEffect(Unit) {
                    onDone((state as AuthState.LoggedIn).token.jwt)
                    authStateHolder.checkAuthState()
                    val role = authStateHolder.userRole.value
                    when (role) {
                        Role.CUSTOMER -> navController.navigate(NavRoutes.ORDERS_LIST) {
                            popUpTo(NavRoutes.LOGIN) { inclusive = true }
                        }
                        Role.CARRIER -> navController.navigate(NavRoutes.ORDERS_SEARCH) {
                            popUpTo(NavRoutes.LOGIN) { inclusive = true }
                        }
                        null -> navController.navigate(NavRoutes.LOGIN)
                    }
                }
                is AuthState.Error -> Text(
                    text = (state as AuthState.Error).msg,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                )
                else -> { /* Idle */ }
            }
        }
    }
}