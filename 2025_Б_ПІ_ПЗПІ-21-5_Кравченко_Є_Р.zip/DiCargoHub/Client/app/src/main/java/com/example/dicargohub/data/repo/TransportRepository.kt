package com.example.dicargohub.data.repo

import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.data.dto.CreateTransportDto
import com.example.dicargohub.data.dto.TransportDto
import com.example.dicargohub.data.dto.UpdateTransportDto
import com.example.dicargohub.data.remote.TransportApi
import retrofit2.HttpException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TransportRepository @Inject constructor(
    private val api: TransportApi,
    private val tokenManager: TokenManager
) {
    private val carrierId: String
        get() = tokenManager.getUserId()
            ?: throw IllegalStateException("No carrierId in token")

    suspend fun create(dto: CreateTransportDto): TransportDto =
        api.createTransport(carrierId, dto)

    suspend fun list(): List<TransportDto> =
        api.getByCarrier(carrierId)

    suspend fun getById(id: String): TransportDto =
        api.getById(id)

    suspend fun update(id: String, dto: UpdateTransportDto): TransportDto =
        api.updateTransport(id, dto)

    suspend fun delete(id: String) {
        val resp = api.deleteTransport(id)
        if (!resp.isSuccessful) {
            throw HttpException(resp)
        }
    }
}