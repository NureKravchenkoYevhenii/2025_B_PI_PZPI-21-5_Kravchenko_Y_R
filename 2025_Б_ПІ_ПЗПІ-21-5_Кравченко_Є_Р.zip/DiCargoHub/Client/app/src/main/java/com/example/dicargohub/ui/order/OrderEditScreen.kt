package com.example.dicargohub.ui.order

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController

import com.example.dicargohub.data.dto.CreateOrderDto
import com.example.dicargohub.data.dto.UpdateOrderDto
import com.example.dicargohub.domain.OrderStatus
import com.example.dicargohub.ui.NavRoutes
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderEditScreen(
    navController: NavController,
    orderId: String? = null,
    vm: OrdersViewModel = hiltViewModel()
) {
    val current by vm.current.collectAsState()
    val state by vm.uiState.collectAsState()
    val offers by vm.offers.collectAsState()

    var cargoDescription by remember { mutableStateOf("") }
    var origin by remember { mutableStateOf("") }
    var destination by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(OrderStatus.PENDING) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(orderId) {
        orderId?.let { vm.loadById(it) }
    }

    LaunchedEffect(current) {
        current?.let {
            cargoDescription = it.cargoDescription
            origin = it.origin
            destination = it.destination
            price = it.price.toString()
            status = it.status
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (orderId == null) "Нове замовлення" else "Редагувати замовлення") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (orderId != null && current == null) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.primary
                )
            } else {
                LazyColumn(
                    Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        errorMessage?.let {
                            Text(
                                text = it,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = cargoDescription,
                            onValueChange = { cargoDescription = it },
                            label = { Text("Опис вантажу") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = origin,
                            onValueChange = { origin = it },
                            label = { Text("Місце завантаження") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = destination,
                            onValueChange = { destination = it },
                            label = { Text("Місце доставки") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = price,
                            onValueChange = { price = it },
                            label = { Text("Ціна") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )
                    }

                    if (orderId != null) {
                        item {
                            var expanded by remember { mutableStateOf(false) }
                            Box {
                                OutlinedTextField(
                                    value = status.displayName,
                                    onValueChange = {},
                                    label = { Text("Статус") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { expanded = true },
                                    enabled = false,
                                    readOnly = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                                    )
                                )
                                DropdownMenu(
                                    expanded = expanded,
                                    onDismissRequest = { expanded = false },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    OrderStatus.values().forEach { st ->
                                        DropdownMenuItem(
                                            text = { Text(st.displayName) },
                                            onClick = {
                                                status = st
                                                expanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Button(
                            onClick = {
                                isLoading = true
                                errorMessage = null
                                val dto = CreateOrderDto(
                                    cargoDescription, origin, destination,
                                    price.toDoubleOrNull() ?: 0.0
                                )
                                if (orderId == null) {
                                    vm.create(dto) {
                                        isLoading = false
                                        navController.popBackStack()
                                    }
                                } else {
                                    vm.update(orderId, UpdateOrderDto(cargoDescription, origin, destination, price.toDoubleOrNull() ?: 0.0)) {
                                        vm.updateStatus(orderId, status) {
                                            isLoading = false
                                            navController.popBackStack()
                                        }
                                    }
                                }
                            },
                            enabled = !isLoading && cargoDescription.isNotBlank() && origin.isNotBlank() && destination.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            } else {
                                Text(if (orderId == null) "Створити замовлення" else "Зберегти")
                            }
                        }
                    }

                    if (orderId != null) {
                        item {
                            OutlinedButton(
                                onClick = {
                                    isLoading = true
                                    errorMessage = null
                                    vm.updateStatus(orderId, OrderStatus.CANCELLED) {
                                        isLoading = false
                                        navController.popBackStack()
                                    }
                                },
                                enabled = !isLoading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(24.dp),
                                        color = MaterialTheme.colorScheme.error
                                    )
                                } else {
                                    Text("Скасувати замовлення")
                                }
                            }
                        }
                    }

                    if (orderId != null && offers.isNotEmpty()) {
                        item {
                            Text(
                                text = "Пропозиції",
                                style = MaterialTheme.typography.titleLarge,
                                modifier = Modifier.padding(vertical = 16.dp)
                            )
                        }

                        items(offers) { offer ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = offer.message,
                                        style = MaterialTheme.typography.bodyLarge
                                    )
                                    if (status == OrderStatus.PENDING) {
                                        Button(
                                            onClick = {
                                                vm.acceptOffer(offer.id) {
                                                    navController.navigate(NavRoutes.ORDERS_LIST) {
                                                        popUpTo(NavRoutes.ORDERS_LIST) { inclusive = true }
                                                    }
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MaterialTheme.colorScheme.primary,
                                                contentColor = MaterialTheme.colorScheme.onPrimary
                                            )
                                        ) {
                                            Text("Прийняти пропозицію")
                                        }
                                    } else {
//                                        Text(
//                                            text = when (offer.status) {
//                                                "Accepted" -> "Пропозицію прийнято"
//                                                "Rejected" -> "Пропозицію відхилено"
//                                                else -> "Статус: ${offer.status}"
//                                            },
//                                            style = MaterialTheme.typography.bodyMedium,
//                                            color = when (offer.status) {
//                                                "Accepted" -> MaterialTheme.colorScheme.primary
//                                                "Rejected" -> MaterialTheme.colorScheme.error
//                                                else -> MaterialTheme.colorScheme.onSurfaceVariant
//                                            }
//                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
