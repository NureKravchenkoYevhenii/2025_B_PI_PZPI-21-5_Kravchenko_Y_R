package com.example.dicargohub.data.dto

import com.example.dicargohub.domain.OrderStatus

data class OrderDetailsDto(
    val id: String,
    val customerId: String,
    val customerName: String?,
    val carrierId: String?,
    val carrierName: String?,
    val status: OrderStatus
) 