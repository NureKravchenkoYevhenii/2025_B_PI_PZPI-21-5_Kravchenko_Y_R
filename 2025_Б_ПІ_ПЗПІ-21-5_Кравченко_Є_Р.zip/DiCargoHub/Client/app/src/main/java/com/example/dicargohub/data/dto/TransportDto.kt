package com.example.dicargohub.data.dto

import com.example.dicargohub.domain.TransportType

data class TransportDto(
    val id: String,
    val type: TransportType,
    val licensePlate: String,
    val capacity: Double,
    val carrierId: String
)