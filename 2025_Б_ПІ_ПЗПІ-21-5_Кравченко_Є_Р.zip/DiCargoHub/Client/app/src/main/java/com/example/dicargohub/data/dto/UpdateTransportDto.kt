package com.example.dicargohub.data.dto

import com.example.dicargohub.domain.TransportType

data class UpdateTransportDto(
    val type: TransportType,
    val licensePlate: String,
    val capacity: Double
)