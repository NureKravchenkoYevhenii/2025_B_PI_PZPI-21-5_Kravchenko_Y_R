package com.example.dicargohub.data.remote

import java.io.File
import java.io.InputStream

interface IpfsService {
    suspend fun uploadFile(file: File): String
    suspend fun uploadFile(inputStream: InputStream, fileName: String): String
    suspend fun uploadFile(bytes: ByteArray, fileName: String): String
    suspend fun getFile(hash: String): ByteArray
    suspend fun deleteFile(hash: String)
} 