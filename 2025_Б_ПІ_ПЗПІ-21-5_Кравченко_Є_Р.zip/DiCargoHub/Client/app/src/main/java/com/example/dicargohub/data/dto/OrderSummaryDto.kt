package com.example.dicargohub.data.dto

data class OrderSummaryDto(
    val id: String,
    val createdOn: String,
    val origin: String,
    val destination: String,
    val status: String,
    val price: Double
)