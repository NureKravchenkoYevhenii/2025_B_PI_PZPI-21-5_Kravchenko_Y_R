package com.example.dicargohub.data.dto
 
data class UploadDocumentDto(
    val name: String,
    val ipfsHash: String
) 