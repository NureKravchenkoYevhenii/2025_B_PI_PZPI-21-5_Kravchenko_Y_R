package com.example.dicargohub.data.dto

data class OfferDto(
    val id: String,
    val carrierId: String,
    val carrierName: String?,
    val orderId: String,
    val orderDescription: String?,
    val status: String,
    val message: String
) 