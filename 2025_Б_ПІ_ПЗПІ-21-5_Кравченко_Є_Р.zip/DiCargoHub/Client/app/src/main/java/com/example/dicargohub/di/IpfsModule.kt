package com.example.dicargohub.di

import com.example.dicargohub.data.remote.IpfsService
import com.example.dicargohub.data.remote.IpfsServiceImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class IpfsModule {
    @Binds
    @Singleton
    abstract fun bindIpfsService(
        ipfsServiceImpl: IpfsServiceImpl
    ): IpfsService
} 