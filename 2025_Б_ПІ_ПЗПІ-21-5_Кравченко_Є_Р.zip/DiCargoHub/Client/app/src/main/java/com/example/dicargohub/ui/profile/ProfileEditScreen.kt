package com.example.dicargohub.ui.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.dicargohub.ui.NavRoutes
import com.example.dicargohub.ui.auth.AuthStateHolder
import com.example.dicargohub.ui.components.CommonTextField

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileEditScreen(
    navController: NavController,
    vm: ProfileViewModel = hiltViewModel(),
    authStateHolder: AuthStateHolder = hiltViewModel()
) {
    val state by vm.profileState.collectAsState()
    val focusManager = LocalFocusManager.current
    var showLogoutDialog by remember { mutableStateOf(false) }

    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Мій профіль",
                        style = MaterialTheme.typography.headlineMedium
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showLogoutDialog = true }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = "Вийти"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (state) {
                is ProfileUiState.Loading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                is ProfileUiState.ProfileLoaded -> {
                    val profile = (state as ProfileUiState.ProfileLoaded).profile

                    LaunchedEffect(profile) {
                        firstName = profile.firstName
                        lastName = profile.lastName
                        email = profile.email
                        phone = profile.phoneNumber.orEmpty()
                        address = profile.address.orEmpty()
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Spacer(modifier = Modifier.height(16.dp))

                        CommonTextField(
                            value = firstName,
                            onValueChange = { firstName = it },
                            label = "Ім'я",
                            modifier = Modifier.fillMaxWidth()
                        )

                        CommonTextField(
                            value = lastName,
                            onValueChange = { lastName = it },
                            label = "Прізвище",
                            modifier = Modifier.fillMaxWidth()
                        )

                        CommonTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = "Email",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier.fillMaxWidth()
                        )

                        CommonTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = "Телефон",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth()
                        )

                        CommonTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = "Адреса",
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                focusManager.clearFocus()
                                vm.saveProfile(
                                    profile.copy(
                                        firstName = firstName,
                                        lastName = lastName,
                                        email = email,
                                        phoneNumber = phone.takeIf { it.isNotBlank() },
                                        address = address.takeIf { it.isNotBlank() }
                                    )
                                )
                            },
                            enabled = firstName.isNotBlank() && lastName.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            Text(
                                "Зберегти",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                }
                is ProfileUiState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = (state as ProfileUiState.Error).message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { vm.loadProfile() }) {
                            Text("Спробувати ще раз")
                        }
                    }
                }

                else -> {}
            }
        }
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Вийти з облікового запису") },
            text = { Text("Ви впевнені, що хочете вийти?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showLogoutDialog = false
                        authStateHolder.logout()
                        authStateHolder.checkAuthState()
                        navController.navigate(NavRoutes.LOGIN) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                ) {
                    Text("Так")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showLogoutDialog = false }
                ) {
                    Text("Ні")
                }
            }
        )
    }
}
