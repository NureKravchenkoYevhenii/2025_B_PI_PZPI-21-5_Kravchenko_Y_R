package com.example.dicargohub.data.auth

import com.example.dicargohub.data.remote.AuthApi
import com.example.dicargohub.di.NetworkModule
import okhttp3.Authenticator
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.Route
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TokenAuthenticator @Inject constructor(
    private val tokenManager: TokenManager
) : Authenticator {

    private val refreshApi by lazy {
        Retrofit.Builder()
            .baseUrl(NetworkModule.BASE_URL)
            .client(OkHttpClient.Builder().build())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AuthApi::class.java)
    }

    override fun authenticate(route: Route?, response: Response): Request? {
        if (responseCount(response) >= 2) return null

        val refreshToken = tokenManager.getRefresh() ?: return null
        val refreshCall = refreshApi.refreshTokenCall(refreshToken)

        return try {
            val refreshResp = refreshCall.execute()
            if (refreshResp.isSuccessful) {
                val tokens = refreshResp.body()!!
                tokenManager.saveTokens(tokens.jwt, tokens.refreshToken)
                response.request.newBuilder()
                    .header("Authorization", "Bearer ${tokens.jwt}")
                    .build()
            } else {
                tokenManager.clear()
                null
            }
        } catch (e: IOException) {
            null
        }
    }

    private fun responseCount(response: Response): Int {
        var res = response.priorResponse
        var result = 1
        while (res != null) {
            result++; res = res.priorResponse
        }
        return result
    }
}
