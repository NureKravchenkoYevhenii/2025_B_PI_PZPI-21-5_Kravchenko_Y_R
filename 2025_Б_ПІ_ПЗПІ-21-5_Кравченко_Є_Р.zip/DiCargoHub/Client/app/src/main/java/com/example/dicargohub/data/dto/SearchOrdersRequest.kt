package com.example.dicargohub.data.dto

import com.example.dicargohub.domain.OrderStatus

data class SearchOrdersRequest(
    val customerId: String?,
    val origin: String? = null,
    val destination: String? = null,
    val status: OrderStatus? = null,
    val pagingModel: PagingModel?
)