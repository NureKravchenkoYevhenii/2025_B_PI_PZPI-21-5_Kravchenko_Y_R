package com.example.dicargohub.ui.ipfs

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.remote.IpfsService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.InputStream
import javax.inject.Inject

@HiltViewModel
class IpfsViewModel @Inject constructor(
    private val ipfsService: IpfsService
) : ViewModel() {

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _uploadedHash = MutableStateFlow<String?>(null)
    val uploadedHash: StateFlow<String?> = _uploadedHash.asStateFlow()

    private val _downloadedFile = MutableStateFlow<ByteArray?>(null)
    val downloadedFile: StateFlow<ByteArray?> = _downloadedFile.asStateFlow()

    fun uploadFile(file: File) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                _uploadedHash.value = ipfsService.uploadFile(file)
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to upload file"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun uploadFile(inputStream: InputStream, fileName: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                _uploadedHash.value = ipfsService.uploadFile(inputStream, fileName)
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to upload file"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getFile(hash: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                _downloadedFile.value = ipfsService.getFile(hash)
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to get file"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteFile(hash: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                ipfsService.deleteFile(hash)
                if (_uploadedHash.value == hash) {
                    _uploadedHash.value = null
                }
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to delete file"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun clearError() {
        _error.value = null
    }

    fun clearDownloadedFile() {
        _downloadedFile.value = null
    }
} 