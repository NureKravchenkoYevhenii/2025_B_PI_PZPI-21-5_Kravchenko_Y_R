package com.example.dicargohub.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.dto.OrderSummaryDto
import com.example.dicargohub.data.dto.UserProfileDto
import com.example.dicargohub.data.repo.ProfileRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class ProfileUiState {
    object Loading : ProfileUiState()
    data class ProfileLoaded(val profile: UserProfileDto) : ProfileUiState()
    data class HistoryLoaded(val orders: List<OrderSummaryDto>) : ProfileUiState()
    data class Error(val message: String) : ProfileUiState()
}

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val repo: ProfileRepository
) : ViewModel() {

    private val _profileState = MutableStateFlow<ProfileUiState>(ProfileUiState.Loading)
    val profileState: StateFlow<ProfileUiState> = _profileState.asStateFlow()

    private val _historyState = MutableStateFlow<ProfileUiState>(ProfileUiState.Loading)
    val historyState: StateFlow<ProfileUiState> = _historyState.asStateFlow()

    init {
        loadProfile()
        loadHistory()
    }

    fun loadProfile() = viewModelScope.launch {
        _profileState.value = ProfileUiState.Loading
        try {
            val p = repo.loadProfile()
            _profileState.value = ProfileUiState.ProfileLoaded(p)
        } catch (e: Exception) {
            _profileState.value = ProfileUiState.Error(e.localizedMessage ?: "Error loading profile")
        }
    }

    fun saveProfile(updated: UserProfileDto) = viewModelScope.launch {
        _profileState.value = ProfileUiState.Loading
        try {
            val saved = repo.saveProfile(updated)
            _profileState.value = ProfileUiState.ProfileLoaded(saved)
        } catch (e: Exception) {
            _profileState.value = ProfileUiState.Error(e.localizedMessage ?: "Error saving profile")
        }
    }

    fun loadHistory() = viewModelScope.launch {
        _historyState.value = ProfileUiState.Loading
        try {
            val list = repo.loadOrderHistory()
            _historyState.value = ProfileUiState.HistoryLoaded(list)
        } catch (e: Exception) {
            _historyState.value = ProfileUiState.Error(e.localizedMessage ?: "Error loading history")
        }
    }
}