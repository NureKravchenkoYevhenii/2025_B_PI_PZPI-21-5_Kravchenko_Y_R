package com.example.dicargohub.data.remote

import com.example.dicargohub.data.dto.AuthTokenResponse
import com.example.dicargohub.data.dto.LoginRequest
import com.example.dicargohub.data.dto.RegisterRequest
import com.example.dicargohub.data.dto.UserDto
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface AuthApi {
    @POST("api/auth/register")
    suspend fun register(@Body req: RegisterRequest): UserDto

    @POST("api/auth/login")
    suspend fun login(@Body req: LoginRequest): AuthTokenResponse

    @POST("api/auth/refresh")
    fun refreshTokenCall(
        @Header("refreshTokenString") refreshToken: String
    ): Call<AuthTokenResponse>

}
