package com.example.dicargohub.data.repo

import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.data.dto.CreateOrderDto
import com.example.dicargohub.data.dto.OrderDto
import com.example.dicargohub.data.dto.OrderDetailsDto
import com.example.dicargohub.data.dto.PagingModel
import com.example.dicargohub.data.dto.SearchOrdersRequest
import com.example.dicargohub.data.dto.UpdateOrderDto
import com.example.dicargohub.data.dto.UpdateStatusDto
import com.example.dicargohub.data.remote.OrderApi
import com.example.dicargohub.domain.OrderStatus
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OrderRepository @Inject constructor(
    private val api: OrderApi,
    private val tokenManager: TokenManager
) {
    private fun userId(): String = tokenManager.getUserId() ?: error("Не авторизований користувач")

    suspend fun getAll(
        origin: String? = null,
        destination: String? = null,
        status: OrderStatus? = null
    ): List<OrderDto> = api.searchOrders(
        SearchOrdersRequest(
            customerId = userId(),
            origin = origin,
            destination = destination,
            status = status,
            pagingModel = PagingModel(pageSize = 50, pageCount = 1)
        )
    )

    suspend fun searchOrders(request: SearchOrdersRequest): List<OrderDto> =
        api.searchOrders(request)

    suspend fun getById(id: String): OrderDto = api.getOrder(id)

    suspend fun getDetailsById(id: String): OrderDetailsDto = api.getDetailsById(id)

    suspend fun create(dto: CreateOrderDto): OrderDto =
        api.createOrder(userId(), dto)

    suspend fun update(id: String, dto: UpdateOrderDto): OrderDto =
        api.updateOrder(id, dto)

    suspend fun updateStatus(id: String, status: OrderStatus) {
        api.updateOrderStatus(id, UpdateStatusDto(status))
    }
}