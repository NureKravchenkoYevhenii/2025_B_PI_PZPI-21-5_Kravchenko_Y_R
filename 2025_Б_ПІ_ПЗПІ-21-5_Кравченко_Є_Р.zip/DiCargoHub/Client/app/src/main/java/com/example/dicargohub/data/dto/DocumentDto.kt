package com.example.dicargohub.data.dto

data class DocumentDto(
    val id: String,
    val name: String,
    val ipfsHash: String,
    val signedByCustomer: Boolean,
    val signedByCarrier: Boolean,
    val orderId: String
) 