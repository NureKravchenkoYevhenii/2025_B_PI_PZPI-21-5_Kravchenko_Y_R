package com.example.dicargohub.ui

object NavRoutes {
    const val REGISTRATION = "registration"
    const val LOGIN = "login"
    const val HOME = "home"
    const val PROFILE = "profile"
    const val HISTORY = "history"
    const val TRANSPORT_LIST = "transports"
    const val TRANSPORT_EDIT_BASE     = "transport_edit"
    const val TRANSPORT_EDIT_WITH_ARG = "transport_edit/{transportId}"
    const val ORDERS_LIST = "orders"
    const val ORDERS_SEARCH = "orders/search"
    const val ORDER_CREATE = "orders/edit"
    const val ORDER_EDIT = "orders/edit/{orderId}"
    const val ORDER_DETAILS = "orders/details/{orderId}?showCreateOfferButton={showCreateOfferButton}"
    const val ORDER_VIEW = "orders/view/{orderId}"
    const val DOCUMENT_DETAILS = "documents/details/{documentId}"
    const val CARRIER_ORDERS_OFFERS = "carrier/orders-offers"

    fun transportEditRoute(id: String?) =
        if (id.isNullOrBlank()) TRANSPORT_EDIT_BASE
        else "$TRANSPORT_EDIT_BASE/$id"

    fun orderDetailsRoute(orderId: String, showCreateOfferButton: Boolean = true) =
        "orders/details/$orderId?showCreateOfferButton=$showCreateOfferButton"

    fun orderViewRoute(orderId: String) = "orders/view/$orderId"

    fun documentDetailsRoute(documentId: String) = "documents/details/$documentId"
}