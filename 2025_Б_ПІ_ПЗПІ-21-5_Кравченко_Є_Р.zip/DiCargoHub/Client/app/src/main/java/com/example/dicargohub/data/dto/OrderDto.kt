package com.example.dicargohub.data.dto

import com.example.dicargohub.domain.OrderStatus

data class OrderDto(
    val id: String,
    val cargoDescription: String,
    val origin: String,
    val destination: String,
    val price: Double,
    val status: OrderStatus
)