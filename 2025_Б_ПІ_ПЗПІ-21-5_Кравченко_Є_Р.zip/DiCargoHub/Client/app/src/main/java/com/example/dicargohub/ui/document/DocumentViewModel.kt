package com.example.dicargohub.ui.document

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.dto.DocumentDto
import com.example.dicargohub.data.dto.UploadDocumentDto
import com.example.dicargohub.data.repo.DocumentRepository
import com.example.dicargohub.data.auth.TokenManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DocumentViewModel @Inject constructor(
    private val repository: DocumentRepository,
    private val tokenManager: TokenManager
) : ViewModel() {

    private val _documents = MutableStateFlow<List<DocumentDto>>(emptyList())
    val documents: StateFlow<List<DocumentDto>> = _documents.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun loadDocumentsByOrder(orderId: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                _documents.value = repository.getDocumentsByOrder(orderId)
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to load documents"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun uploadDocument(orderId: String, name: String, ipfsHash: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                repository.uploadDocument(orderId, UploadDocumentDto(name, ipfsHash))
                _documents.value = repository.getDocumentsByOrder(orderId)
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to upload document"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun signDocument(documentId: String, signerUserId: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                repository.signDocument(documentId, signerUserId)
                // Refresh documents after signing by reloading from API
                val doc = repository.getDocumentById(documentId)
                _documents.value = repository.getDocumentsByOrder(doc.orderId)
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to sign document"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun clearError() {
        _error.value = null
    }

    fun loadDocumentById(documentId: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                val doc = repository.getDocumentById(documentId)
                val current = _documents.value.toMutableList()
                val idx = current.indexOfFirst { it.id == doc.id }
                if (idx >= 0) current[idx] = doc else current.add(doc)
                _documents.value = current
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to load document"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getCurrentUserId(): String? = tokenManager.getUserId()

    fun signDocument(documentId: String) {
        val userId = getCurrentUserId() ?: return
        signDocument(documentId, userId)
    }
} 