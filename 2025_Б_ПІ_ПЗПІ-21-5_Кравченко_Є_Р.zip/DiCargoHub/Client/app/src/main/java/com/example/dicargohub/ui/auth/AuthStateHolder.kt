package com.example.dicargohub.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.domain.Role
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthStateHolder @Inject constructor(
    private val tokenManager: TokenManager
) : ViewModel() {
    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated

    private val _userRole = MutableStateFlow<Role?>(null)
    val userRole: StateFlow<Role?> = _userRole

    init {
        checkAuthState()
    }

    fun checkAuthState() {
        viewModelScope.launch {
            val jwt = tokenManager.getJwt()
            _isAuthenticated.value = !jwt.isNullOrBlank()
            _userRole.value = tokenManager.getUserRole()
        }
    }

    fun logout() {
        viewModelScope.launch {
            tokenManager.clear()
            _isAuthenticated.value = false
            _userRole.value = null
        }
    }
} 