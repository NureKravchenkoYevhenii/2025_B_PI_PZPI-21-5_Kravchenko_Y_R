package com.example.dicargohub.data.repo

import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.data.dto.OrderSummaryDto
import com.example.dicargohub.data.dto.UserProfileDto
import com.example.dicargohub.data.remote.ProfileApi
import retrofit2.HttpException
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProfileRepository @Inject constructor(
    private val api: ProfileApi,
    private val tokenManager: TokenManager
) {
    private val userId: String
        get() = tokenManager.getUserId()
            ?: throw IllegalStateException("User not logged in")

    suspend fun loadProfile(): UserProfileDto =
        api.getProfile(userId)

    suspend fun saveProfile(profile: UserProfileDto): UserProfileDto {
        val resp = api.updateProfile(userId, profile)
        if (resp.isSuccessful) {
            return profile
        } else {
            throw HttpException(Response.error<Unit>(resp.code(), resp.errorBody()!!))
        }
    }

    suspend fun loadOrderHistory(page: Int = 1, pageSize: Int = 50): List<OrderSummaryDto> =
        api.getOrderHistory(userId, page, pageSize)
}