package com.example.dicargohub.data.remote

import com.example.dicargohub.data.dto.OrderSummaryDto
import com.example.dicargohub.data.dto.UserProfileDto
import retrofit2.http.GET
import retrofit2.http.PUT
import retrofit2.http.Query
import retrofit2.http.Body
import retrofit2.http.Path

interface ProfileApi {
    @GET("api/users/profile/{userId}")
    suspend fun getProfile(
        @Path("userId") userId: String
    ): UserProfileDto

    @PUT("api/users/profile/{userId}")
    suspend fun updateProfile(
        @Path("userId") userId: String,
        @Body profile: UserProfileDto
    ): retrofit2.Response<Unit>

    @GET("api/users/orders/history/{userId}")
    suspend fun getOrderHistory(
        @Path("userId") userId: String,
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 50
    ): List<OrderSummaryDto>
}