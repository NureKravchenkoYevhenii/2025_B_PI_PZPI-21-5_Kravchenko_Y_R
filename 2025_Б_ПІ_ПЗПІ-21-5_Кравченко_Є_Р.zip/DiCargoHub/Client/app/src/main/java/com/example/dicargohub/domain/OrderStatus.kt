package com.example.dicargohub.domain

import com.google.gson.annotations.SerializedName

enum class OrderStatus(val displayName: String) {
    @SerializedName("Pending")
    PENDING("Очікується"),

    @SerializedName("Offered")
    OFFERED("Запропоновано"),

    @SerializedName("InProgress")
    IN_PROGRESS("В процесі"),

    @SerializedName("WaitingForComplete")
    WAITING_FOR_COMPLETE("Очікує завершення"),

    @SerializedName("Completed")
    COMPLETED("Завершено"),

    @SerializedName("Cancelled")
    CANCELLED("Скасовано")
}