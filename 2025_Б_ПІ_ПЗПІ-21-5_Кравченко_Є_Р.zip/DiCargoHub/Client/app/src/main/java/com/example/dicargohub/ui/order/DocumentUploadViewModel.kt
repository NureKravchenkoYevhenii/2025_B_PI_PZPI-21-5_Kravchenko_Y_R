package com.example.dicargohub.ui.order

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.dto.DocumentDto
import com.example.dicargohub.data.dto.UploadDocumentDto
import com.example.dicargohub.data.remote.IpfsService
import com.example.dicargohub.data.repo.DocumentRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.InputStream
import javax.inject.Inject

sealed class DocumentUploadState {
    object Idle : DocumentUploadState()
    object Loading : DocumentUploadState()
    data class Success(val documents: List<DocumentDto>) : DocumentUploadState()
    data class Error(val message: String) : DocumentUploadState()
}

@HiltViewModel
class DocumentUploadViewModel @Inject constructor(
    private val ipfsService: IpfsService,
    private val documentRepository: DocumentRepository
) : ViewModel() {

    private val _state = MutableStateFlow<DocumentUploadState>(DocumentUploadState.Idle)
    val state: StateFlow<DocumentUploadState> = _state.asStateFlow()

    fun uploadDocument(orderId: String, file: File) {
        viewModelScope.launch {
            try {
                _state.value = DocumentUploadState.Loading
                val ipfsHash = ipfsService.uploadFile(file)
                val document = UploadDocumentDto(
                    name = file.name,
                    ipfsHash = ipfsHash
                )
                documentRepository.uploadDocument(orderId, document)
                loadDocuments(orderId)
            } catch (e: Exception) {
                _state.value = DocumentUploadState.Error(e.message ?: "Failed to upload document")
            }
        }
    }

    fun uploadDocument(orderId: String, inputStream: InputStream, fileName: String) {
        viewModelScope.launch {
            try {
                _state.value = DocumentUploadState.Loading
                val bytes = inputStream.readBytes();
                val ipfsHash = ipfsService.uploadFile(bytes, fileName)
                val document = UploadDocumentDto(
                    name = fileName,
                    ipfsHash = ipfsHash
                )
                documentRepository.uploadDocument(orderId, document)
                loadDocuments(orderId)
            } catch (e: Exception) {
                _state.value = DocumentUploadState.Error(e.message ?: "Failed to upload document")
            }
        }
    }

    fun loadDocuments(orderId: String) {
        viewModelScope.launch {
            try {
                _state.value = DocumentUploadState.Loading
                val documents = documentRepository.getDocumentsByOrder(orderId)
                _state.value = DocumentUploadState.Success(documents)
            } catch (e: Exception) {
                _state.value = DocumentUploadState.Error(e.message ?: "Failed to load documents")
            }
        }
    }
} 