package com.example.dicargohub.data.repo

import com.example.dicargohub.data.dto.LoginRequest
import com.example.dicargohub.data.dto.RegisterRequest
import com.example.dicargohub.data.remote.AuthApi
import javax.inject.Inject

class AuthRepository @Inject constructor(
    private val api: AuthApi
) {
    suspend fun register(login: String, pwd: String, role: String) =
        api.register(RegisterRequest(login, pwd, role))

    suspend fun login(login: String, pwd: String) =
        api.login(LoginRequest(login, pwd))
}
