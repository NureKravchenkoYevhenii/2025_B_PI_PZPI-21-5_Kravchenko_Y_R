package com.example.dicargohub.data.remote

import com.example.dicargohub.data.dto.CreateOfferDto
import com.example.dicargohub.data.dto.OfferDto
import retrofit2.Response
import retrofit2.http.*

interface OfferApi {
    @POST("api/offers/create")
    suspend fun createOffer(
        @Header("X-Carrier-UserId") carrierId: String,
        @Body dto: CreateOfferDto
    ): OfferDto

    @GET("api/offers/order/{orderId}")
    suspend fun getOffersByOrder(
        @Path("orderId") orderId: String
    ): List<OfferDto>

    @POST("api/offers/{id}/accept")
    suspend fun acceptOffer(
        @Path("id") offerId: String
    ): Response<Unit>

    @GET("api/offers/carrier/{carrierId}")
    suspend fun getPendingByCarrier(
        @Path("carrierId") carrierId: String
    ): List<OfferDto>

    @DELETE("api/offers/{id}")
    suspend fun deleteOffer(
        @Header("X-Carrier-UserId") carrierId: String,
        @Path("id") offerId: String
    ): Response<Unit>
}
 