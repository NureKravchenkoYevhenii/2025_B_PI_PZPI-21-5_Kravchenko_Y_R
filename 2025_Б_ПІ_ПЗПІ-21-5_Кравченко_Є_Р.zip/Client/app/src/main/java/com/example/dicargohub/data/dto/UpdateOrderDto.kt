package com.example.dicargohub.data.dto

data class UpdateOrderDto(
    val cargoDescription: String,
    val origin: String,
    val destination: String,
    val price: Double
)