package com.example.dicargohub.data.dto

data class RegisterRequest(val login: String, val password: String, val role: String)