package com.example.dicargohub.domain

enum class Role(val displayName: String) {
    CUSTOMER("Замовник"),
    CARRIER("Перевізник");

    companion object {
        fun fromString(value: String): Role {
            return entries.find { it.name == value.uppercase() } ?: CUSTOMER
        }
    }
}
