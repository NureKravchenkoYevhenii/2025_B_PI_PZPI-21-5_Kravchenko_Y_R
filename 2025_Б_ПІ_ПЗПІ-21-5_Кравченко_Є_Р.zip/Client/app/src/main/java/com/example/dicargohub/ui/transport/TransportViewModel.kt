package com.example.dicargohub.ui.transport

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.dto.CreateTransportDto
import com.example.dicargohub.data.dto.TransportDto
import com.example.dicargohub.data.dto.UpdateTransportDto
import com.example.dicargohub.data.repo.TransportRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class TransportUiState {
    object Loading : TransportUiState()
    data class Success(val transports: List<TransportDto>) : TransportUiState()
    data class Error  (val message: String) : TransportUiState()
}

@HiltViewModel
class TransportViewModel @Inject constructor(
    private val repo: TransportRepository
): ViewModel() {

    private val _state = MutableStateFlow<TransportUiState>(TransportUiState.Loading)
    val state: StateFlow<TransportUiState> = _state.asStateFlow()

    private val _current = MutableStateFlow<TransportDto?>(null)
    val current: StateFlow<TransportDto?> = _current

    init {
        loadAll()
    }

    fun loadAll() = viewModelScope.launch {
        _state.value = TransportUiState.Loading
        try {
            val list = repo.list()
            _state.value = TransportUiState.Success(list)
        } catch (e: Exception) {
            _state.value = TransportUiState.Error(e.localizedMessage ?: "Error loading transports")
        }
    }

    fun loadById(id: String) = viewModelScope.launch {
        try {
            val t = repo.getById(id)
            _current.value = t
        } catch (e: Exception) {
            // можна поставити якийсь error state
        }
    }

    fun create(dto: CreateTransportDto, onDone: ()->Unit) = viewModelScope.launch {
        try {
            repo.create(dto)
            loadAll()
            onDone()
        } catch (e: Exception) {
            _state.value = TransportUiState.Error(e.localizedMessage ?: "Create failed")
        }
    }

    fun update(id: String, dto: UpdateTransportDto, onDone: ()->Unit) = viewModelScope.launch {
        try {
            repo.update(id, dto)
            loadAll()
            onDone()
        } catch (e: Exception) {
            _state.value = TransportUiState.Error(e.localizedMessage ?: "Update failed")
        }
    }

    fun delete(id: String) = viewModelScope.launch {
        try {
            repo.delete(id)
            loadAll()
        } catch (e: Exception) {
            _state.value = TransportUiState.Error(e.localizedMessage ?: "Delete failed")
        }
    }
}