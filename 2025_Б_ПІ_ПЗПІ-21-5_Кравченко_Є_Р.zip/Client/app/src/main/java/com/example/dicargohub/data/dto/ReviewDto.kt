package com.example.dicargohub.data.dto

data class ReviewDto(
    val id: String,
    val orderId: String,
    val ratedUserId: String,
    val reviewerId: String,
    val score: Int,
    val comments: String?
) 