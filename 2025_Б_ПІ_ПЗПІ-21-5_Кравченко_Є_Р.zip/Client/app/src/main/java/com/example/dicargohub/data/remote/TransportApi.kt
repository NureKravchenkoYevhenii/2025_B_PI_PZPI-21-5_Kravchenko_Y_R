package com.example.dicargohub.data.remote

import com.example.dicargohub.data.dto.CreateTransportDto
import com.example.dicargohub.data.dto.TransportDto
import com.example.dicargohub.data.dto.UpdateTransportDto
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface TransportApi {
    @POST("api/transports/create")
    suspend fun createTransport(
        @Header("X-Carrier-UserId") carrierId: String,
        @Body dto: CreateTransportDto
    ): TransportDto

    @GET("api/transports/carrier/{carrierId}")
    suspend fun getByCarrier(
        @Path("carrierId") carrierId: String
    ): List<TransportDto>

    @GET("api/transports/{id}")
    suspend fun getById(
        @Path("id") transportId: String
    ): TransportDto

    @PUT("api/transports/{transportId}")
    suspend fun updateTransport(
        @Path("transportId") transportId: String,
        @Body dto: UpdateTransportDto
    ): TransportDto

    @DELETE("api/transports/{transportId}")
    suspend fun deleteTransport(
        @Path("transportId") transportId: String
    ): retrofit2.Response<Unit>
}