package com.example.dicargohub.ui.theme

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ThemeManager @Inject constructor() {
    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun setTheme(isDark: Boolean) {
        _isDarkTheme.value = isDark
    }
}

@HiltViewModel
class ThemeState @Inject constructor(
    private val themeManager: ThemeManager
) : ViewModel() {
    val isDarkTheme: StateFlow<Boolean> = themeManager.isDarkTheme

    fun toggleTheme() {
        themeManager.toggleTheme()
    }

    fun setTheme(isDark: Boolean) {
        themeManager.setTheme(isDark)
    }
} 