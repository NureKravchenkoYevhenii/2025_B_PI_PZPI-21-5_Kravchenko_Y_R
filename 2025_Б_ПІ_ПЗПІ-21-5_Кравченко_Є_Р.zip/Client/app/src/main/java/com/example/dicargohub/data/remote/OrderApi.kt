package com.example.dicargohub.data.remote

import com.example.dicargohub.data.dto.CreateOrderDto
import com.example.dicargohub.data.dto.OrderDetailsDto
import com.example.dicargohub.data.dto.OrderDto
import com.example.dicargohub.data.dto.SearchOrdersRequest
import com.example.dicargohub.data.dto.UpdateOrderDto
import com.example.dicargohub.data.dto.UpdateStatusDto
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface OrderApi {
    @POST("api/orders/create")
    suspend fun createOrder(
        @Header("X-Customer-UserId") customerId: String,
        @Body dto: CreateOrderDto
    ): OrderDto

    @GET("api/orders/{id}")
    suspend fun getOrder(@Path("id") id: String): OrderDto

    @GET("api/orders/details/{id}")
    suspend fun getDetailsById(@Path("id") id: String): OrderDetailsDto

    @POST("api/orders/search")
    suspend fun searchOrders(@Body request: SearchOrdersRequest): List<OrderDto>

    @PUT("api/orders/{id}")
    suspend fun updateOrder(
        @Path("id") id: String,
        @Body dto: UpdateOrderDto
    ): OrderDto

    @PUT("api/orders/{id}/status")
    suspend fun updateOrderStatus(
        @Path("id") id: String,
        @Body status: UpdateStatusDto
    ): retrofit2.Response<Unit>

    @GET("api/orders/carrier/{carrierId}")
    suspend fun getActiveOrdersByCarrier(
        @Path("carrierId") carrierId: String
    ): List<OrderDto>

    @GET("api/orders/carrier/{carrierId}/history")
    suspend fun getHistoryOrdersByCarrier(
        @Path("carrierId") carrierId: String
    ): List<OrderDto>
}