package com.example.dicargohub.data.repo

import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.data.dto.CreateOfferDto
import com.example.dicargohub.data.dto.OfferDto
import com.example.dicargohub.data.remote.OfferApi
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OfferRepository @Inject constructor(
    private val api: OfferApi,
    private val tokenManager: TokenManager
) {
    private fun carrierId(): String = tokenManager.getUserId() ?: error("Не авторизований користувач")

    suspend fun createOffer(dto: CreateOfferDto) {
        api.createOffer(carrierId(), dto)
    }

    suspend fun getOffersByOrder(orderId: String): List<OfferDto> {
        return api.getOffersByOrder(orderId)
    }

    suspend fun acceptOffer(offerId: String): Result<Unit> {
        return try {
            val response = api.acceptOffer(offerId)
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to accept offer: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getPendingByCarrier(): List<OfferDto> {
        return api.getPendingByCarrier(carrierId())
    }

    suspend fun deleteOffer(offerId: String): Result<Unit> {
        return try {
            val response = api.deleteOffer(carrierId(), offerId)
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to delete offer: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
 