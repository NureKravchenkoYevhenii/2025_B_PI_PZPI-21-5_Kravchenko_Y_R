package com.example.dicargohub.ui.order

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.dicargohub.data.dto.DocumentDto
import com.example.dicargohub.data.dto.OrderDto
import com.example.dicargohub.domain.OrderStatus
import com.example.dicargohub.ui.NavRoutes
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderViewScreen(
    navController: NavController,
    orderId: String,
    vm: OrdersViewModel = hiltViewModel(),
    documentVm: DocumentUploadViewModel = hiltViewModel()
) {
    val current by vm.current.collectAsState()
    val details by vm.details.collectAsState()
    val documentState by documentVm.state.collectAsState()
    val context = LocalContext.current

    var showDocumentDialog by remember { mutableStateOf(false) }

    val documentPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            context.contentResolver.openInputStream(it)?.use { inputStream ->
                val fileName = context.contentResolver.getType(it)?.let { mimeType ->
                    "document_${System.currentTimeMillis()}.${mimeType.split("/").last()}"
                } ?: "document_${System.currentTimeMillis()}"
                documentVm.uploadDocument(orderId, inputStream, fileName)
            }
        }
    }

    LaunchedEffect(orderId) {
        vm.loadById(orderId)
        vm.loadDetails(orderId)
        documentVm.loadDocuments(orderId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Замовлення",
                        style = MaterialTheme.typography.headlineMedium
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (navController.previousBackStackEntry != null) {
                                navController.popBackStack()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                current == null || details == null -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                else -> {
                    val orderDetails = details!!
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        OrderDetailCard(
                            title = "Замовник",
                            content = orderDetails.customerName ?: "Невідомо"
                        )

                        if (orderDetails.carrierName != null) {
                            OrderDetailCard(
                                title = "Перевізник",
                                content = orderDetails.carrierName
                            )
                        }

                        OrderDetailCard(
                            title = "Статус",
                            content = orderDetails.status.displayName
                        )

                        // Show ReadyToShip button only for customer and when status is Offered
                        if (orderDetails.customerId == vm.getCurrentUserId() && 
                            orderDetails.status == OrderStatus.OFFERED) {
                            Button(
                                onClick = { 
                                    vm.updateStatus(orderId, OrderStatus.READY_TO_SHIP) {
                                        vm.loadById(orderId)
                                        vm.loadDetails(orderId)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                Text("Підтвердити готовність до відправки")
                            }
                        }

                        // Show complete button for customer when order is waiting for completion
                        if (orderDetails.customerId == vm.getCurrentUserId() && 
                            orderDetails.status == OrderStatus.WAITING_FOR_COMPLETE) {
                            Button(
                                onClick = { 
                                    vm.updateStatus(orderId, OrderStatus.COMPLETED) {
                                        vm.loadById(orderId)
                                        vm.loadDetails(orderId)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                Text("Підтвердити завершення замовлення")
                            }
                        }

                        // Show buttons for carrier
                        if (orderDetails.carrierId == vm.getCurrentUserId()) {
                            // Button for ReadyToShip -> InProgress
                            if (orderDetails.status == OrderStatus.READY_TO_SHIP) {
                                Button(
                                    onClick = { 
                                        vm.updateStatus(orderId, OrderStatus.IN_PROGRESS) {
                                            vm.loadById(orderId)
                                            vm.loadDetails(orderId)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                ) {
                                    Text("Почати доставку")
                                }
                            }

                            // Button for InProgress -> WaitingForComplete
                            if (orderDetails.status == OrderStatus.IN_PROGRESS) {
                                Button(
                                    onClick = { 
                                        vm.updateStatus(orderId, OrderStatus.WAITING_FOR_COMPLETE) {
                                            vm.loadById(orderId)
                                            vm.loadDetails(orderId)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                ) {
                                    Text("Завершити доставку")
                                }
                            }
                        }

                        // Documents section
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Документи",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    IconButton(onClick = { documentPicker.launch("*/*") }) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = "Додати документ"
                                        )
                                    }
                                }

                                when (documentState) {
                                    is DocumentUploadState.Loading -> {
                                        CircularProgressIndicator(
                                            modifier = Modifier.align(Alignment.CenterHorizontally)
                                        )
                                    }
                                    is DocumentUploadState.Success -> {
                                        val documents = (documentState as DocumentUploadState.Success).documents
                                        if (documents.isEmpty()) {
                                            Text(
                                                text = "Немає документів",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                            )
                                        } else {
                                            documents.forEach { document ->
                                                DocumentItem(document, onClick = {
                                                    navController.navigate(NavRoutes.documentDetailsRoute(document.id))
                                                })
                                            }
                                        }
                                    }
                                    is DocumentUploadState.Error -> {
                                        Text(
                                            text = (documentState as DocumentUploadState.Error).message,
                                            color = MaterialTheme.colorScheme.error,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                    else -> {}
                                }
                            }
                        }

                        Button(
                            onClick = { navController.navigate(NavRoutes.orderDetailsRoute(orderId)) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        ) {
                            Text("Деталі")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DocumentItem(document: DocumentDto, onClick: (() -> Unit)? = null) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.clickable { onClick() } else it }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = document.name,
                style = MaterialTheme.typography.bodyMedium
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (document.signedByCustomer) {
                    Text(
                        text = "✓",
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                if (document.signedByCarrier) {
                    Text(
                        text = "✓",
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
    }
}

@Composable
private fun OrderDetailCard(
    title: String,
    content: String
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = content,
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
} 