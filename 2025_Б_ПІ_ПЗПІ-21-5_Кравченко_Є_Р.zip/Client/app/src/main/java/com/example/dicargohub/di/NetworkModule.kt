package com.example.dicargohub.di

import com.example.dicargohub.data.auth.AuthInterceptor
import com.example.dicargohub.data.auth.TokenAuthenticator
import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.data.remote.AuthApi
import com.example.dicargohub.data.remote.DocumentApi
import com.example.dicargohub.data.remote.OfferApi
import com.example.dicargohub.data.remote.OrderApi
import com.example.dicargohub.data.remote.ProfileApi
import com.example.dicargohub.data.remote.ReviewApi
import com.example.dicargohub.data.remote.TransportApi
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    const val BASE_URL = "http://192.168.0.102:5062/"

    @Provides @Singleton
    fun provideLoggingInterceptor() = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    @Provides @Singleton
    fun provideAuthInterceptor(tokenManager: TokenManager) =
        AuthInterceptor(tokenManager)

    @Provides @Singleton
    fun provideTokenAuthenticator(
        tokenManager: TokenManager
    ) = TokenAuthenticator(tokenManager)

    @Provides @Singleton
    fun provideOkHttp(
        logging: HttpLoggingInterceptor,
        authInterceptor: AuthInterceptor
    ): OkHttpClient  = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .addInterceptor(logging)
        .build()

    @Provides @Singleton
    fun provideRetrofit(client: OkHttpClient): Retrofit =
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    @Provides @Singleton
    fun provideAuthApi(retrofit: Retrofit): AuthApi =
        retrofit.create(AuthApi::class.java)

    @Provides @Singleton
    fun provideProfileApi(retrofit: Retrofit): ProfileApi =
        retrofit.create(ProfileApi::class.java)

    @Provides @Singleton
    fun provideTransportApi(retrofit: Retrofit): TransportApi =
        retrofit.create(TransportApi::class.java)

    @Provides @Singleton
    fun provideOrderApi(retrofit: Retrofit): OrderApi =
        retrofit.create(OrderApi::class.java)

    @Provides @Singleton
    fun provideOfferApi(retrofit: Retrofit): OfferApi =
        retrofit.create(OfferApi::class.java)

    @Provides @Singleton
    fun provideDocumentApi(retrofit: Retrofit): DocumentApi =
        retrofit.create(DocumentApi::class.java)

    @Provides @Singleton
    fun provideReviewApi(retrofit: Retrofit): ReviewApi =
        retrofit.create(ReviewApi::class.java)
}