package com.example.dicargohub.data.auth

import android.content.Context
import android.util.Base64
import com.example.dicargohub.domain.Role
import javax.inject.Inject
import javax.inject.Singleton
import androidx.core.content.edit
import dagger.hilt.android.qualifiers.ApplicationContext
import org.json.JSONObject

@Singleton
class TokenManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val PREFS_NAME = "auth_prefs"
        private const val KEY_JWT = "jwt_token"
        private const val KEY_REFRESH_JWT = "refresh_token"
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun saveTokens(jwt: String, refresh: String) {
        prefs.edit {
            putString(KEY_JWT, jwt)
                .putString(KEY_REFRESH_JWT, refresh)
        }
    }

    fun getJwt(): String? =
        prefs.getString(KEY_JWT, null)

    fun getRefresh(): String? =
        prefs.getString(KEY_REFRESH_JWT, null)

    fun clear() {
        prefs.edit { clear() }
    }

    fun getUserId(): String? {
        val token = getJwt() ?: return null
        val parts = token.split(".")
        if (parts.size < 2) return null
        return try {
            val payload = String(
                Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP),
                Charsets.UTF_8
            )
            JSONObject(payload).optString("id", null)
        } catch (e: Exception) {
            null
        }
    }

    fun getUserRole(): Role? {
        val token = getJwt() ?: return null
        val parts = token.split(".")
        if (parts.size < 2) return null
        return try {
            val payload = String(
                Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP),
                Charsets.UTF_8
            )
            val role = JSONObject(payload).optString("role", null)
            Role.fromString(role)
        } catch (e: Exception) {
            null
        }
    }
}