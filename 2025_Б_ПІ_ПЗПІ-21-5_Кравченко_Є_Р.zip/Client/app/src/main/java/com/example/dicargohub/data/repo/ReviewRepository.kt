package com.example.dicargohub.data.repo

import com.example.dicargohub.data.dto.CreateReviewDto
import com.example.dicargohub.data.dto.ReviewDto
import com.example.dicargohub.data.remote.ReviewApi
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReviewRepository @Inject constructor(
    private val api: ReviewApi
) {
    suspend fun addReview(
        orderId: String,
        reviewerId: String,
        dto: CreateReviewDto
    ): ReviewDto = api.addReview(orderId, reviewerId, dto)

    suspend fun getAverageRating(ratedUserId: String): Double =
        api.getAverageRating(ratedUserId)

    suspend fun getReviewsByOrder(orderId: String): List<ReviewDto> =
        api.getReviewsByOrder(orderId)
} 