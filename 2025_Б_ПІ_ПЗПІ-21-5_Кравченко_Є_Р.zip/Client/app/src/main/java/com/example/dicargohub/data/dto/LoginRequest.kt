package com.example.dicargohub.data.dto

data class LoginRequest(val login: String, val password: String)