package com.example.dicargohub.ui.order

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.dicargohub.data.dto.DocumentDto
import com.example.dicargohub.data.dto.OrderDto
import com.example.dicargohub.data.dto.ReviewDto
import com.example.dicargohub.domain.OrderStatus
import com.example.dicargohub.ui.NavRoutes
import com.example.dicargohub.ui.ipfs.IpfsViewModel
import android.os.Environment
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderHistoryDetailsScreen(
    navController: NavController,
    orderId: String,
    vm: OrdersViewModel = hiltViewModel(),
    documentVm: DocumentUploadViewModel = hiltViewModel(),
    ipfsVm: IpfsViewModel = hiltViewModel(),
    reviewVm: ReviewViewModel = hiltViewModel()
) {
    val current by vm.current.collectAsState()
    val details by vm.details.collectAsState()
    val documentState by documentVm.state.collectAsState()
    val reviews by reviewVm.reviews.collectAsState()
    val context = LocalContext.current
    var showDownloadSuccess by remember { mutableStateOf(false) }
    var showReviewDialog by remember { mutableStateOf(false) }
    var selectedUserId by remember { mutableStateOf<String?>(null) }

    val ipfsLoading by ipfsVm.isLoading.collectAsState()
    val ipfsError by ipfsVm.error.collectAsState()
    val downloadedFile by ipfsVm.downloadedFile.collectAsState()

    // Handle file save after download
    LaunchedEffect(downloadedFile) {
        downloadedFile?.let { bytes ->
            try {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val file = File(downloadsDir, "document_${System.currentTimeMillis()}")
                FileOutputStream(file).use { it.write(bytes) }
                showDownloadSuccess = true
                Toast.makeText(context, "Файл збережено у Завантаженнях", Toast.LENGTH_LONG).show()
                ipfsVm.clearDownloadedFile()
            } catch (e: Exception) {
                Toast.makeText(context, "Помилка збереження файлу: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(orderId) {
        vm.loadById(orderId)
        vm.loadDetails(orderId)
        documentVm.loadDocuments(orderId)
        reviewVm.loadReviewsByOrder(orderId)
    }

    if (showReviewDialog && selectedUserId != null) {
        ReviewDialog(
            onDismiss = { showReviewDialog = false },
            onSubmit = { score, comments ->
                reviewVm.addReview(orderId, selectedUserId!!, score, comments)
                showReviewDialog = false
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Деталі замовлення",
                        style = MaterialTheme.typography.headlineMedium
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (navController.previousBackStackEntry != null) {
                                navController.popBackStack()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                current == null || details == null -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                else -> {
                    val orderDetails = details!!
                    val order = current!!
                    val currentUserId = reviewVm.getCurrentUserId()
                    
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Customer section with review
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Замовник",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    
                                    val customerReview = reviews.find { it.ratedUserId == orderDetails.customerId }
                                    if (customerReview != null) {
                                        Text(
                                            text = "Оцінка: ${customerReview.score}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    } else if (currentUserId != orderDetails.customerId) {
                                        Button(
                                            onClick = {
                                                selectedUserId = orderDetails.customerId
                                                showReviewDialog = true
                                            }
                                        ) {
                                            Text("Оцінити")
                                        }
                                    }
                                }
                                Text(
                                    text = orderDetails.customerName ?: "Невідомо",
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                        }

                        // Carrier section with review
                        if (orderDetails.carrierName != null) {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Перевізник",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        
                                        val carrierReview = reviews.find { it.ratedUserId == orderDetails.carrierId }
                                        if (carrierReview != null) {
                                            Text(
                                                text = "Оцінка: ${carrierReview.score}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        } else if (currentUserId != orderDetails.carrierId) {
                                            Button(
                                                onClick = {
                                                    selectedUserId = orderDetails.carrierId
                                                    showReviewDialog = true
                                                }
                                            ) {
                                                Text("Оцінити")
                                            }
                                        }
                                    }
                                    Text(
                                        text = orderDetails.carrierName,
                                        style = MaterialTheme.typography.bodyLarge
                                    )
                                }
                            }
                        }

                        OrderDetailCard(
                            title = "Статус",
                            content = orderDetails.status.displayName
                        )

                        OrderDetailCard(
                            title = "Опис вантажу",
                            content = order.cargoDescription
                        )

                        OrderDetailCard(
                            title = "Місце завантаження",
                            content = order.origin
                        )

                        OrderDetailCard(
                            title = "Місце розвантаження",
                            content = order.destination
                        )

                        OrderDetailCard(
                            title = "Ціна",
                            content = "${order.price} ₴"
                        )

                        // Documents section
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Документи",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                
                                when (documentState) {
                                    is DocumentUploadState.Loading -> {
                                        CircularProgressIndicator(
                                            modifier = Modifier.align(Alignment.CenterHorizontally)
                                        )
                                    }
                                    is DocumentUploadState.Error -> {
                                        Text(
                                            text = (documentState as DocumentUploadState.Error).message,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                    is DocumentUploadState.Success -> {
                                        val documents = (documentState as DocumentUploadState.Success).documents
                                        if (documents.isEmpty()) {
                                            Text(
                                                text = "Документи відсутні",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        } else {
                                            documents.forEach { document ->
                                                DocumentItem(document, onClick = {
                                                    document.ipfsHash.let { ipfsVm.getFile(it) }
                                                })
                                            }
                                        }
                                    }

                                    else -> {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReviewDialog(
    onDismiss: () -> Unit,
    onSubmit: (score: Int, comments: String?) -> Unit
) {
    var score by remember { mutableStateOf(5) }
    var comments by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Оцініть учасника") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Оцінка: $score")
                Slider(
                    value = score.toFloat(),
                    onValueChange = { score = it.toInt() },
                    valueRange = 1f..5f,
                    steps = 3
                )
                OutlinedTextField(
                    value = comments,
                    onValueChange = { comments = it },
                    label = { Text("Коментар (необов'язково)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(score, comments.takeIf { it.isNotBlank() }) }
            ) {
                Text("Підтвердити")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Скасувати")
            }
        }
    )
}

@Composable
private fun DocumentItem(
    document: DocumentDto,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier
            .fillMaxWidth()
            .let { it.clickable { onClick() } }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = document.name,
                style = MaterialTheme.typography.bodyMedium
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (document.signedByCustomer) {
                    Text(
                        text = "✓",
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                if (document.signedByCarrier) {
                    Text(
                        text = "✓",
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
    }
}

@Composable
private fun OrderDetailCard(
    title: String,
    content: String
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = content,
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
} 