package com.example.dicargohub.ui.order

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.data.dto.OrderDto
import com.example.dicargohub.data.repo.OrderRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CarrierOrderHistoryViewModel @Inject constructor(
    private val orderRepository: OrderRepository,
    private val tokenManager: TokenManager
) : ViewModel() {

    private val _orders = MutableStateFlow<List<OrderDto>>(emptyList())
    val orders: StateFlow<List<OrderDto>> = _orders.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun loadHistoryOrders() {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                val carrierId = tokenManager.getUserId() ?: throw IllegalStateException("User not authorized")
                _orders.value = orderRepository.getHistoryOrdersByCarrier(carrierId)
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to load order history"
            } finally {
                _isLoading.value = false
            }
        }
    }
} 