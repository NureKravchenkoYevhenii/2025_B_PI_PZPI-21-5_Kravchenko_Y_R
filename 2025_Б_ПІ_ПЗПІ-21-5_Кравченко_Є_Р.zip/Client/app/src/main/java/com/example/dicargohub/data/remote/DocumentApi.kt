package com.example.dicargohub.data.remote

import com.example.dicargohub.data.dto.DocumentDto
import com.example.dicargohub.data.dto.UploadDocumentDto
import retrofit2.Response
import retrofit2.http.*

interface DocumentApi {
    @POST("api/documents/{orderId}/upload")
    suspend fun uploadDocument(
        @Path("orderId") orderId: String,
        @Body dto: UploadDocumentDto
    ): DocumentDto

    @POST("api/documents/{id}/sign")
    suspend fun signDocument(
        @Path("id") documentId: String,
        @Header("X-Signer-UserId") signerUserId: String
    ): Response<Unit>

    @GET("api/documents/order/{orderId}")
    suspend fun getDocumentsByOrder(
        @Path("orderId") orderId: String
    ): List<DocumentDto>

    @GET("api/documents/{id}")
    suspend fun getDocumentById(
        @Path("id") documentId: String
    ): DocumentDto
} 