package com.example.dicargohub.ui.order

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.dicargohub.ui.NavRoutes
import com.example.dicargohub.ui.components.CommonTextField

@Composable
fun SearchOrdersScreen(
    navController: NavController,
    vm: SearchOrdersViewModel = hiltViewModel()
) {
    val state by vm.uiState.collectAsState()
    val listState = rememberLazyListState()
    var showFilters by remember { mutableStateOf(false) }
    var origin by remember { mutableStateOf("") }
    var destination by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        vm.search()
    }

    LaunchedEffect(listState) {
        snapshotFlow {
            listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index
        }.collect { lastIndex ->
            if (lastIndex != null) {
                val totalItems = listState.layoutInfo.totalItemsCount
                if (lastIndex >= totalItems - 5) {
                    vm.loadMore()
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            if (showFilters) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CommonTextField(
                            value = origin,
                            onValueChange = { origin = it },
                            label = "Місце завантаження",
                            trailingIcon = {
                                if (origin.isNotBlank()) {
                                    IconButton(onClick = { origin = "" }) {
                                        Icon(Icons.Default.Clear, "Очистити")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        CommonTextField(
                            value = destination,
                            onValueChange = { destination = it },
                            label = "Місце розвантаження",
                            trailingIcon = {
                                if (destination.isNotBlank()) {
                                    IconButton(onClick = { destination = "" }) {
                                        Icon(Icons.Default.Clear, "Очистити")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { showFilters = false },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Скасувати")
                            }
                            Button(
                                onClick = {
                                    vm.search(
                                        origin = origin.takeIf { it.isNotBlank() },
                                        destination = destination.takeIf { it.isNotBlank() }
                                    )
                                    showFilters = false
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Пошук")
                            }
                        }
                    }
                }
            }

            when (state) {
                is SearchOrdersUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                is SearchOrdersUiState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = (state as SearchOrdersUiState.Error).message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { vm.reset() }) {
                            Text("Спробувати ще раз")
                        }
                    }
                }
                is SearchOrdersUiState.Success -> {
                    val orders = (state as SearchOrdersUiState.Success).orders
                    if (orders.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Замовлень не знайдено",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            state = listState,
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(orders) { order ->
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            navController.navigate(NavRoutes.orderDetailsRoute(order.id, showCreateOfferButton = true))
                                        },
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp)
                                    ) {
                                        Text(
                                            text = order.cargoDescription,
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text(
                                                    text = order.origin,
                                                    style = MaterialTheme.typography.bodyMedium
                                                )
                                                Text(
                                                    text = order.destination,
                                                    style = MaterialTheme.typography.bodyMedium
                                                )
                                            }
                                            Text(
                                                text = "${order.price} ₴",
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = order.status.displayName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Search button
        FloatingActionButton(
            onClick = { showFilters = !showFilters },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        ) {
            Icon(Icons.Default.Search, contentDescription = "Пошук")
        }
    }
} 