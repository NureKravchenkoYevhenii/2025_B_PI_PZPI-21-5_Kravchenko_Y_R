package com.example.dicargohub.data.dto

data class CreateOfferDto(
    val orderId: String,
    val message: String
)
