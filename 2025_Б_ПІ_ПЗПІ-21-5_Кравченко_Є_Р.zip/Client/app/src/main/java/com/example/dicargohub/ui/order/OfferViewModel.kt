package com.example.dicargohub.ui.order

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.dto.OfferDto
import com.example.dicargohub.data.repo.OfferRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OfferViewModel @Inject constructor(
    private val offerRepository: OfferRepository
) : ViewModel() {
    private val _offers = MutableStateFlow<List<OfferDto>>(emptyList())
    val offers: StateFlow<List<OfferDto>> = _offers.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun loadPendingOffers() {
        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null
            try {
                _offers.value = offerRepository.getPendingByCarrier()
            } catch (e: Exception) {
                _error.value = e.message ?: "Помилка завантаження пропозицій"
            } finally {
                _isLoading.value = false
            }
        }
    }

    suspend fun deleteOffer(offerId: String): Result<Unit> {
        return offerRepository.deleteOffer(offerId)
    }
} 