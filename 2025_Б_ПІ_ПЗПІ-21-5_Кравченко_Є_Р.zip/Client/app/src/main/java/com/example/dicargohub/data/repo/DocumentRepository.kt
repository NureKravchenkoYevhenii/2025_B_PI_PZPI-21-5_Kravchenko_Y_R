package com.example.dicargohub.data.repo

import com.example.dicargohub.data.dto.DocumentDto
import com.example.dicargohub.data.dto.UploadDocumentDto
import com.example.dicargohub.data.remote.DocumentApi
import javax.inject.Inject

class DocumentRepository @Inject constructor(
    private val api: DocumentApi
) {
    suspend fun uploadDocument(orderId: String, dto: UploadDocumentDto): DocumentDto {
        return api.uploadDocument(orderId, dto)
    }

    suspend fun signDocument(documentId: String, signerUserId: String) {
        api.signDocument(documentId, signerUserId)
    }

    suspend fun getDocumentsByOrder(orderId: String): List<DocumentDto> {
        return api.getDocumentsByOrder(orderId)
    }

    suspend fun getDocumentById(documentId: String): DocumentDto {
        return api.getDocumentById(documentId)
    }
} 