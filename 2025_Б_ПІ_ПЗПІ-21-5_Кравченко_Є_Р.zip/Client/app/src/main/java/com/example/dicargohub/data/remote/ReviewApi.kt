package com.example.dicargohub.data.remote

import com.example.dicargohub.data.dto.CreateReviewDto
import com.example.dicargohub.data.dto.ReviewDto
import retrofit2.http.*

interface ReviewApi {
    @POST("api/reviews/{orderId}/add")
    suspend fun addReview(
        @Path("orderId") orderId: String,
        @Header("X-Reviewer-UserId") reviewerId: String,
        @Body dto: CreateReviewDto
    ): ReviewDto

    @GET("api/reviews/average/{ratedUserId}")
    suspend fun getAverageRating(
        @Path("ratedUserId") ratedUserId: String
    ): Double

    @GET("api/reviews/order/{orderId}")
    suspend fun getReviewsByOrder(
        @Path("orderId") orderId: String
    ): List<ReviewDto>
} 