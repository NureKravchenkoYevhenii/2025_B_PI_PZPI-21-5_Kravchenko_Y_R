package com.example.dicargohub.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.dicargohub.domain.Role
import com.example.dicargohub.ui.auth.AuthStateHolder
import com.example.dicargohub.ui.auth.AuthViewModel
import com.example.dicargohub.ui.auth.LoginScreen
import com.example.dicargohub.ui.auth.RegistrationScreen
import com.example.dicargohub.ui.order.OrderEditScreen
import com.example.dicargohub.ui.order.OrdersListScreen
import com.example.dicargohub.ui.profile.OrderHistoryScreen
import com.example.dicargohub.ui.profile.ProfileEditScreen
import com.example.dicargohub.ui.profile.ProfileViewModel
import com.example.dicargohub.ui.transport.TransportEditScreen
import com.example.dicargohub.ui.transport.TransportListScreen
import com.example.dicargohub.ui.order.SearchOrdersScreen
import com.example.dicargohub.ui.order.SearchOrdersViewModel
import com.example.dicargohub.ui.order.OrderDetailsScreen
import com.example.dicargohub.ui.order.OrderViewScreen
import com.example.dicargohub.ui.order.OrdersViewModel
import com.example.dicargohub.ui.document.DocumentDetailsScreen
import com.example.dicargohub.ui.order.OrderHistoryDetailsScreen
import com.example.dicargohub.ui.profile.UserProfileScreen

@Composable
fun AppNavGraph(
    navController: NavHostController,
    authStateHolder: AuthStateHolder
) {
    val isAuthenticated by authStateHolder.isAuthenticated.collectAsState()
    val userRole by authStateHolder.userRole.collectAsState()

    val startDestination = when {
        !isAuthenticated -> NavRoutes.LOGIN
        userRole == Role.CUSTOMER -> NavRoutes.ORDERS_LIST
        userRole == Role.CARRIER -> NavRoutes.CARRIER_ORDERS_OFFERS
        else -> NavRoutes.LOGIN
    }

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        // Auth routes
        composable(NavRoutes.REGISTRATION) {
            val vm: AuthViewModel = hiltViewModel()
            RegistrationScreen(
                vm = vm,
                navController = navController
            ) {
                    navController.navigate(NavRoutes.LOGIN) {
                        popUpTo(NavRoutes.REGISTRATION) { inclusive = true }
                    }
            }
        }
        composable(NavRoutes.LOGIN) {
            val vm: AuthViewModel = hiltViewModel()
            LoginScreen(
                vm = vm,
                navController = navController,
                authStateHolder = authStateHolder
            ) { jwt ->
                val role = authStateHolder.userRole.value
                when (role) {
                    Role.CUSTOMER -> navController.navigate(NavRoutes.ORDERS_LIST) {
                        popUpTo(NavRoutes.LOGIN) { inclusive = true }
                    }
                    Role.CARRIER -> navController.navigate(NavRoutes.ORDERS_SEARCH) {
                    popUpTo(NavRoutes.LOGIN) { inclusive = true }
                }
                    null -> navController.navigate(NavRoutes.LOGIN)
                }
            }
        }

        // Protected routes
        composable(NavRoutes.PROFILE) {
            if (isAuthenticated) {
                val vm: ProfileViewModel = hiltViewModel()
                ProfileEditScreen(navController = navController, vm = vm, authStateHolder = authStateHolder)
            }
        }

        composable(
            route = NavRoutes.USER_PROFILE,
            arguments = listOf(
                navArgument("userId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            if (isAuthenticated) {
                val userId = backStackEntry.arguments?.getString("userId")
                if (userId != null) {
                    UserProfileScreen(
                        navController = navController,
                        userId = userId
                    )
                }
            }
        }

        composable(NavRoutes.HISTORY) {
            if (isAuthenticated) {
                val vm: OrdersViewModel = hiltViewModel()
            OrderHistoryScreen(vm) { orderId ->
                    navController.navigate(NavRoutes.orderHistoryDetailsRoute(orderId))
                }
            }
        }
        composable(NavRoutes.TRANSPORT_LIST) {
            if (isAuthenticated) {
            TransportListScreen(navToEdit = { id ->
                navController.navigate(NavRoutes.transportEditRoute(id))
            })
            }
        }
        composable(NavRoutes.TRANSPORT_EDIT_BASE) {
            if (isAuthenticated) {
            TransportEditScreen(transportId = null) {
                navController.popBackStack()
                }
            }
        }
        composable(
            route = NavRoutes.TRANSPORT_EDIT_WITH_ARG,
            arguments = listOf(
                navArgument("transportId") {
                    type = NavType.StringType
                    defaultValue = ""
                    nullable = true
                }
            )
        ) { backStackEntry ->
            if (isAuthenticated) {
            val raw = backStackEntry.arguments?.getString("transportId")
            val transportId = raw?.takeIf(String::isNotBlank)
            TransportEditScreen(
                transportId = transportId,
                onDone = { navController.popBackStack() }
            )
        }
        }
        composable(NavRoutes.ORDERS_LIST) {
            if (isAuthenticated) {
                OrdersListScreen(navController)
            }
        }
        composable(NavRoutes.ORDER_CREATE) {
            if (isAuthenticated) {
                OrderEditScreen(navController)
            }
        }
        composable(NavRoutes.ORDER_EDIT) { backStack ->
            if (isAuthenticated) {
            OrderEditScreen(navController, orderId = backStack.arguments?.getString("orderId"))
            }
        }
        composable(NavRoutes.ORDERS_SEARCH) {
            if (isAuthenticated) {
                val vm: SearchOrdersViewModel = hiltViewModel()
                SearchOrdersScreen(navController = navController, vm = vm)
            }
        }
        composable(
            route = NavRoutes.ORDER_DETAILS,
            arguments = listOf(
                navArgument("orderId") { type = NavType.StringType },
                navArgument("showCreateOfferButton") {
                    type = NavType.BoolType
                    defaultValue = true
                }
            )
        ) { backStack ->
            if (isAuthenticated) {
                val showCreateOfferButton = backStack.arguments?.getBoolean("showCreateOfferButton") ?: true
                OrderDetailsScreen(
                    navController = navController,
                    orderId = backStack.arguments?.getString("orderId") ?: "",
                    showCreateOfferButton = showCreateOfferButton
                )
            }
        }
        composable(
            route = NavRoutes.ORDER_VIEW,
            arguments = listOf(navArgument("orderId") { type = NavType.StringType })
        ) { backStack ->
            if (isAuthenticated) {
                OrderViewScreen(
                    navController = navController,
                    orderId = backStack.arguments?.getString("orderId") ?: ""
                )
            }
        }
        composable(
            route = NavRoutes.ORDER_HISTORY_DETAILS,
            arguments = listOf(navArgument("orderId") { type = NavType.StringType })
        ) { backStack ->
            if (isAuthenticated) {
                OrderHistoryDetailsScreen(
                    navController = navController,
                    orderId = backStack.arguments?.getString("orderId") ?: ""
                )
            }
        }
        composable(
            route = NavRoutes.DOCUMENT_DETAILS,
            arguments = listOf(navArgument("documentId") { type = NavType.StringType })
        ) { backStack ->
            if (isAuthenticated) {
                DocumentDetailsScreen(
                    navController = navController,
                    documentId = backStack.arguments?.getString("documentId") ?: ""
                )
            }
        }
        composable(NavRoutes.CARRIER_ORDERS_OFFERS) {
            if (isAuthenticated) {
                com.example.dicargohub.ui.order.CarrierOrdersAndOffersScreen(navController)
            }
        }
        composable(NavRoutes.CARRIER_ORDER_HISTORY) {
            if (isAuthenticated) {
                com.example.dicargohub.ui.order.CarrierOrderHistoryScreen(navController)
            }
        }
    }
}