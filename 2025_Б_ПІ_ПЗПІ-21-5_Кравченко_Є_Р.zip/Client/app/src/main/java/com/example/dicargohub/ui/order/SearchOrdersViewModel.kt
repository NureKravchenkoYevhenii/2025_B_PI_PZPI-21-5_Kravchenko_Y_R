package com.example.dicargohub.ui.order

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.dto.OrderDto
import com.example.dicargohub.data.dto.PagingModel
import com.example.dicargohub.data.dto.SearchOrdersRequest
import com.example.dicargohub.data.repo.OrderRepository
import com.example.dicargohub.domain.OrderStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class SearchOrdersUiState {
    object Loading : SearchOrdersUiState()
    data class Error(val message: String) : SearchOrdersUiState()
    data class Success(
        val orders: List<OrderDto>,
        val hasMore: Boolean,
        val currentPage: Int
    ) : SearchOrdersUiState()
}

@HiltViewModel
class SearchOrdersViewModel @Inject constructor(
    private val repo: OrderRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow<SearchOrdersUiState>(SearchOrdersUiState.Loading)
    val uiState: StateFlow<SearchOrdersUiState> = _uiState.asStateFlow()

    private var currentPage = 1
    private var currentOrigin: String? = null
    private var currentDestination: String? = null

    fun search(
        origin: String? = null,
        destination: String? = null,
        resetPage: Boolean = true
    ) = viewModelScope.launch {
        if (resetPage) {
            currentPage = 1
            currentOrigin = origin
            currentDestination = destination
        }

        try {
            val request = SearchOrdersRequest(
                customerId = null, // Search all orders
                origin = origin,
                destination = destination,
                status = OrderStatus.PENDING, // Always filter by pending status
                pagingModel = PagingModel(pageSize = 20, pageCount = currentPage)
            )

            val orders = repo.searchOrders(request)
            val hasMore = orders.size == 20 // If we got full page, there might be more

            _uiState.value = SearchOrdersUiState.Success(
                orders = if (resetPage) orders else (_uiState.value as? SearchOrdersUiState.Success)?.orders.orEmpty() + orders,
                hasMore = hasMore,
                currentPage = currentPage
            )

            if (!resetPage) {
                currentPage++
            }
        } catch (e: Exception) {
            _uiState.value = SearchOrdersUiState.Error(e.localizedMessage ?: "Помилка пошуку замовлень")
        }
    }

    fun loadMore() {
        if (_uiState.value is SearchOrdersUiState.Success) {
            val state = _uiState.value as SearchOrdersUiState.Success
            if (state.hasMore) {
                search(
                    origin = currentOrigin,
                    destination = currentDestination,
                    resetPage = false
                )
            }
        }
    }

    fun reset() {
        currentPage = 1
        currentOrigin = null
        currentDestination = null
        search()
    }
} 