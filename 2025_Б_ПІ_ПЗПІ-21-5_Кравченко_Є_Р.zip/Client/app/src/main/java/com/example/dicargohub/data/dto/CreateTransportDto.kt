package com.example.dicargohub.data.dto

import com.example.dicargohub.domain.TransportType

data class CreateTransportDto(
    val type: TransportType,
    val licensePlate: String,
    val capacity: Double
)