package com.example.dicargohub.data.dto

data class UserDto(val id: String, val login: String, val role: String)