package com.example.dicargohub.ui.document

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.dicargohub.data.dto.DocumentDto
import kotlinx.coroutines.launch
import com.example.dicargohub.ui.ipfs.IpfsViewModel
import android.os.Environment
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentDetailsScreen(
    navController: NavController,
    documentId: String,
    vm: DocumentViewModel = hiltViewModel(),
    ipfsVm: IpfsViewModel = hiltViewModel()
) {
    val documents by vm.documents.collectAsState()
    val isLoading by vm.isLoading.collectAsState()
    val error by vm.error.collectAsState()
    val document = documents.find { it.id == documentId }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showDownloadSuccess by remember { mutableStateOf(false) }
    var showSignSuccess by remember { mutableStateOf(false) }

    val ipfsLoading by ipfsVm.isLoading.collectAsState()
    val ipfsError by ipfsVm.error.collectAsState()
    val downloadedFile by ipfsVm.downloadedFile.collectAsState()

    // If document not loaded, fetch it (assume orderId is not needed for single doc fetch)
    LaunchedEffect(documentId) {
        if (document == null) {
            vm.loadDocumentById(documentId)
        }
    }

    // Handle file save after download
    LaunchedEffect(downloadedFile) {
        downloadedFile?.let { bytes ->
            try {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val file = File(downloadsDir, document?.name ?: "document")
                FileOutputStream(file).use { it.write(bytes) }
                showDownloadSuccess = true
                Toast.makeText(context, "Файл збережено у Завантаженнях", Toast.LENGTH_LONG).show()
                ipfsVm.clearDownloadedFile()
            } catch (e: Exception) {
                Toast.makeText(context, "Помилка збереження файлу: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Show sign success message
    LaunchedEffect(isLoading) {
        if (!isLoading && showSignSuccess) {
            Toast.makeText(context, "Документ підписано!", Toast.LENGTH_LONG).show()
            showSignSuccess = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Документ", style = MaterialTheme.typography.headlineMedium)
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (isLoading || ipfsLoading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            } else if (error != null) {
                Text(
                    text = error ?: "",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.align(Alignment.Center),
                    style = MaterialTheme.typography.bodyLarge
                )
            } else if (ipfsError != null) {
                Text(
                    text = ipfsError ?: "",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.align(Alignment.Center),
                    style = MaterialTheme.typography.bodyLarge
                )
            } else if (document != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    Text(
                        text = "Назва: ${document.name}",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Підписано замовником: ", style = MaterialTheme.typography.bodyLarge)
                        if (document.signedByCustomer) {
                            Text("Так", color = MaterialTheme.colorScheme.primary)
                        } else {
                            Text("Ні", color = MaterialTheme.colorScheme.error)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Підписано перевізником: ", style = MaterialTheme.typography.bodyLarge)
                        if (document.signedByCarrier) {
                            Text("Так", color = MaterialTheme.colorScheme.primary)
                        } else {
                            Text("Ні", color = MaterialTheme.colorScheme.error)
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(onClick = {
                            document.ipfsHash.let { ipfsVm.getFile(it) }
                        }) {
                            Text("Завантажити")
                        }
                        Button(onClick = {
                            coroutineScope.launch {
                                showSignSuccess = false
                                vm.signDocument(document.id)
                                showSignSuccess = true
                            }
                        }) {
                            Text("Підписати")
                        }
                    }
                    if (showDownloadSuccess) {
                        Text(
                            text = "Файл завантажено!",
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }
} 