package com.example.dicargohub.data.dto

data class PagingModel(
    val pageSize: Int,
    val pageCount: Int
)