package com.example.dicargohub.ui.order

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.data.dto.CreateReviewDto
import com.example.dicargohub.data.dto.ReviewDto
import com.example.dicargohub.data.repo.ReviewRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReviewViewModel @Inject constructor(
    private val reviewRepository: ReviewRepository,
    private val tokenManager: TokenManager
) : ViewModel() {

    private val _reviews = MutableStateFlow<List<ReviewDto>>(emptyList())
    val reviews: StateFlow<List<ReviewDto>> = _reviews.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun loadReviewsByOrder(orderId: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                _reviews.value = reviewRepository.getReviewsByOrder(orderId)
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to load reviews"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun addReview(orderId: String, ratedUserId: String, score: Int, comments: String?) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                val reviewerId = tokenManager.getUserId() ?: throw IllegalStateException("User not authorized")
                val dto = CreateReviewDto(ratedUserId, score, comments)
                reviewRepository.addReview(orderId, reviewerId, dto)
                loadReviewsByOrder(orderId) // Reload reviews after adding
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to add review"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getCurrentUserId(): String = tokenManager.getUserId() ?: error("User not authorized")
} 