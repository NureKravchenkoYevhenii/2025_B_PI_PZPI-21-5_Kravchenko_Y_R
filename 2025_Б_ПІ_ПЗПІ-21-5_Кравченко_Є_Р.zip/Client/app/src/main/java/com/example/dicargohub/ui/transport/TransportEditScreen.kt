package com.example.dicargohub.ui.transport

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.dicargohub.data.dto.CreateTransportDto
import com.example.dicargohub.data.dto.UpdateTransportDto
import com.example.dicargohub.domain.TransportType
import com.example.dicargohub.ui.components.CommonTextField

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransportEditScreen(
    transportId: String?,
    vm: TransportViewModel = hiltViewModel(),
    onDone: () -> Unit
) {
    val focusManager = LocalFocusManager.current
    val current by vm.current.collectAsState()
    val state by vm.state.collectAsState()

    var plate by remember { mutableStateOf("") }
    var capacity by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(TransportType.TRUCK) }
    var capacityError by remember { mutableStateOf(false) }

    LaunchedEffect(transportId) {
        transportId?.let { vm.loadById(it) }
    }

    LaunchedEffect(current) {
        current?.let {
            plate = it.licensePlate
            capacity = it.capacity.toString()
            type = it.type
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        if (transportId == null) "Новий транспорт" else "Редагувати транспорт",
                        style = MaterialTheme.typography.headlineMedium
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { onDone() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (transportId != null && current == null) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Spacer(modifier = Modifier.height(16.dp))

                    TransportTypeSelector(
                        type = type,
                        onTypeSelected = { type = it }
                    )

                    CommonTextField(
                        value = plate,
                        onValueChange = { plate = it },
                        label = "Номерний знак",
                        modifier = Modifier.fillMaxWidth()
                    )

                    CommonTextField(
                        value = capacity,
                        onValueChange = {
                            capacity = it.filter { ch -> ch.isDigit() || ch == '.' }
                            capacityError = capacity.toDoubleOrNull() == null && capacity.isNotBlank()
                        },
                        label = "Вантажопідйомність (тонн)",
                        isError = capacityError,
                        errorMessage = if (capacityError) "Введіть дійсне число" else null,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            val cap = capacity.toDoubleOrNull() ?: 0.0
                            if (transportId == null) {
                                vm.create(CreateTransportDto(type, plate, cap), onDone)
                            } else {
                                vm.update(transportId, UpdateTransportDto(type, plate, cap), onDone)
                            }
                            focusManager.clearFocus()
                        },
                        enabled = plate.isNotBlank() && capacity.toDoubleOrNull() != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                    ) {
                        Text(
                            "Зберегти",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }

            when (state) {
                TransportUiState.Loading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                is TransportUiState.Error -> {
                    Text(
                        text = (state as TransportUiState.Error).message,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                    )
                }
                else -> { /* Idle */ }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransportTypeSelector(
    type: TransportType,
    onTypeSelected: (TransportType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = type.displayName,
            onValueChange = {},
            readOnly = true,
            label = { Text("Тип транспорту") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.DirectionsBus,
                    contentDescription = null
                )
            },
            trailingIcon = {
                ExposedDropdownMenuDefaults.TrailingIcon(expanded)
            },
            modifier = Modifier
                .menuAnchor(MenuAnchorType.PrimaryEditable)
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            TransportType.entries.forEach { trType ->
                DropdownMenuItem(
                    text = { Text(trType.displayName) },
                    onClick = {
                        onTypeSelected(trType)
                        expanded = false
                    }
                )
            }
        }
    }
}