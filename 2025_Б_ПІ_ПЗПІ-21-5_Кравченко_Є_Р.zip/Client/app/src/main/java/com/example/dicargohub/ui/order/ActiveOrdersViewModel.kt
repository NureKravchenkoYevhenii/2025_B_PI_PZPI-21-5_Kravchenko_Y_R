package com.example.dicargohub.ui.order

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.data.dto.OrderDto
import com.example.dicargohub.data.repo.OrderRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ActiveOrdersViewModel @Inject constructor(
    private val orderRepository: OrderRepository,
    private val tokenManager: TokenManager
) : ViewModel() {
    private val _orders = MutableStateFlow<List<OrderDto>>(emptyList())
    val orders: StateFlow<List<OrderDto>> = _orders.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun loadActiveOrders() {
        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null
            try {
                val userId = tokenManager.getUserId() ?: throw Exception("Не авторизований користувач")
                _orders.value = orderRepository.getActiveOrdersByCarrier(userId)
            } catch (e: Exception) {
                _error.value = e.message ?: "Помилка завантаження замовлень"
            } finally {
                _isLoading.value = false
            }
        }
    }
} 