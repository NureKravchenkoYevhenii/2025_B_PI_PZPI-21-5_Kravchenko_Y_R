package com.example.dicargohub.ui.order

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.dicargohub.data.dto.OrderDto
import com.example.dicargohub.domain.OrderStatus
import com.example.dicargohub.ui.NavRoutes
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderDetailsScreen(
    navController: NavController,
    orderId: String,
    showCreateOfferButton: Boolean = true,
    vm: OrdersViewModel = hiltViewModel()
) {
    val current by vm.current.collectAsState()
    val offerState by vm.offerState.collectAsState()
    var showOfferDialog by remember { mutableStateOf(false) }
    var offerMessage by remember { mutableStateOf("") }

    LaunchedEffect(orderId) {
        vm.loadById(orderId)
    }

    LaunchedEffect(offerState) {
        if (offerState is OfferState.Success) {
            showOfferDialog = false
            offerMessage = ""
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Деталі замовлення",
                        style = MaterialTheme.typography.headlineMedium
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (navController.previousBackStackEntry != null) {
                                navController.popBackStack()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                current == null -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                else -> {
                    val order = current!!
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Customer section
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Замовник",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = order.customerName ?: "Невідомо",
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.clickable {
                                        navController.navigate(NavRoutes.userProfileRoute(order.customerId))
                                    }
                                )
                            }
                        }

                        OrderDetailCard(
                            title = "Опис вантажу",
                            content = order.cargoDescription
                        )

                        OrderDetailCard(
                            title = "Місце завантаження",
                            content = order.origin
                        )

                        OrderDetailCard(
                            title = "Місце доставки",
                            content = order.destination
                        )

                        OrderDetailCard(
                            title = "Ціна",
                            content = "${order.price} ₴"
                        )

                        OrderDetailCard(
                            title = "Статус",
                            content = order.status.displayName
                        )

                        if (showCreateOfferButton && order.status == OrderStatus.PENDING) {
                            Button(
                                onClick = { showOfferDialog = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Створити пропозицію")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showOfferDialog) {
        AlertDialog(
            onDismissRequest = { showOfferDialog = false },
            title = { Text("Створити пропозицію") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OutlinedTextField(
                        value = offerMessage,
                        onValueChange = { offerMessage = it },
                        label = { Text("Повідомлення") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (offerState is OfferState.Error) {
                        Text(
                            text = (offerState as OfferState.Error).message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (offerMessage.isNotEmpty()) {
                            vm.createOffer(orderId, offerMessage) {
                                // Handle success
                            }
                        }
                    },
                    enabled = offerMessage.isNotEmpty() && offerState !is OfferState.Loading
                ) {
                    Text("Створити")
                }
            },
            dismissButton = {
                TextButton(onClick = { showOfferDialog = false }) {
                    Text("Скасувати")
                }
            }
        )
    }
}

@Composable
private fun OrderDetailCard(
    title: String,
    content: String
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = content,
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}
