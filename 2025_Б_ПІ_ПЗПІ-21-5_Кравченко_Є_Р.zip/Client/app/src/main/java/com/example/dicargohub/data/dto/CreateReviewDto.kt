package com.example.dicargohub.data.dto
 
data class CreateReviewDto(
    val ratedUserId: String,
    val score: Int,
    val comments: String?
) 