package com.example.dicargohub.ui.order

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.data.dto.CreateOrderDto
import com.example.dicargohub.data.dto.CreateOfferDto
import com.example.dicargohub.data.dto.OrderDto
import com.example.dicargohub.data.dto.OrderDetailsDto
import com.example.dicargohub.data.dto.OfferDto
import com.example.dicargohub.data.dto.UpdateOrderDto
import com.example.dicargohub.data.repo.OrderRepository
import com.example.dicargohub.data.repo.OfferRepository
import com.example.dicargohub.domain.OrderStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OrdersViewModel @Inject constructor(
    private val orderRepo: OrderRepository,
    private val offerRepo: OfferRepository,
    private val tokenManager: TokenManager
) : ViewModel() {
    private val _uiState = MutableStateFlow<OrdersUiState>(OrdersUiState.Loading)
    val uiState: StateFlow<OrdersUiState> = _uiState.asStateFlow()

    private val _current = MutableStateFlow<OrderDto?>(null)
    val current: StateFlow<OrderDto?> = _current.asStateFlow()

    private val _details = MutableStateFlow<OrderDetailsDto?>(null)
    val details: StateFlow<OrderDetailsDto?> = _details.asStateFlow()

    private val _offerState = MutableStateFlow<OfferState>(OfferState.Idle)
    val offerState: StateFlow<OfferState> = _offerState.asStateFlow()

    private val _offers = MutableStateFlow<List<OfferDto>>(emptyList())
    val offers: StateFlow<List<OfferDto>> = _offers.asStateFlow()

    fun getCurrentUserId(): String = tokenManager.getUserId() ?: error("Не авторизований користувач")

    fun loadAll(showHistory: Boolean = false) = viewModelScope.launch {
        _uiState.value = OrdersUiState.Loading
        try {
            val orders = orderRepo.getAll()
            val filteredOrders = if (showHistory) {
                orders.filter { it.status == OrderStatus.COMPLETED || it.status == OrderStatus.CANCELLED }
            } else {
                orders.filter { it.status != OrderStatus.COMPLETED && it.status != OrderStatus.CANCELLED }
            }
            _uiState.value = OrdersUiState.Success(filteredOrders)
        } catch (e: Exception) {
            _uiState.value = OrdersUiState.Error(e.localizedMessage ?: "Помилка завантаження замовлень")
        }
    }

    fun loadById(id: String) = viewModelScope.launch {
        _current.value = null
        try {
            _current.value = orderRepo.getById(id)
            loadOffers(id)
        } catch (e: Exception) {
            // Handle error if needed
        }
    }

    fun loadDetails(id: String) = viewModelScope.launch {
        _details.value = null
        try {
            _details.value = orderRepo.getDetailsById(id)
        } catch (e: Exception) {
            // Handle error if needed
        }
    }

    private fun loadOffers(orderId: String) = viewModelScope.launch {
        try {
            _offers.value = offerRepo.getOffersByOrder(orderId)
        } catch (e: Exception) {
            // Handle error if needed
        }
    }

    fun create(dto: CreateOrderDto, onDone: () -> Unit) = viewModelScope.launch {
        try {
            orderRepo.create(dto)
            loadAll() // Refresh the list
            onDone()
        } catch (e: Exception) {
            _uiState.value = OrdersUiState.Error(e.localizedMessage ?: "Помилка створення замовлення")
        }
    }

    fun update(id: String, dto: UpdateOrderDto, onDone: () -> Unit) = viewModelScope.launch {
        try {
            orderRepo.update(id, dto)
            loadAll() // Refresh the list
            onDone()
        } catch (e: Exception) {
            _uiState.value = OrdersUiState.Error(e.localizedMessage ?: "Помилка оновлення замовлення")
        }
    }

    fun updateStatus(id: String, status: OrderStatus, onDone: () -> Unit) = viewModelScope.launch {
        try {
            orderRepo.updateStatus(id, status)
            loadAll() // Refresh the list
            onDone()
        } catch (e: Exception) {
            _uiState.value = OrdersUiState.Error(e.localizedMessage ?: "Помилка оновлення статусу замовлення")
        }
    }

    fun createOffer(orderId: String, message: String, onDone: () -> Unit) = viewModelScope.launch {
        _offerState.value = OfferState.Loading
        try {
            offerRepo.createOffer(CreateOfferDto(orderId, message))
            _offerState.value = OfferState.Success
            loadOffers(orderId) // Refresh offers list
            onDone()
        } catch (e: Exception) {
            _offerState.value = OfferState.Error(e.localizedMessage ?: "Помилка створення пропозиції")
        }
    }

    fun acceptOffer(offerId: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _offerState.value = OfferState.Loading
            offerRepo.acceptOffer(offerId).fold(
                onSuccess = {
                    _offerState.value = OfferState.Success
                    _current.value?.let { loadOffers(it.id) }
                    onSuccess()
                },
                onFailure = {
                    _offerState.value = OfferState.Error(it.message ?: "Failed to accept offer")
                }
            )
        }
    }
}

sealed class OfferState {
    object Idle : OfferState()
    object Loading : OfferState()
    object Success : OfferState()
    data class Error(val message: String) : OfferState()
}