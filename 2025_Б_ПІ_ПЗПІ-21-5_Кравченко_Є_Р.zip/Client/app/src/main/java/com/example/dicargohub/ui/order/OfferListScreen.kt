package com.example.dicargohub.ui.order

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.dicargohub.ui.NavRoutes
import kotlinx.coroutines.launch
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun OfferListScreen(
    navController: NavController,
    vm: OfferViewModel = hiltViewModel()
) {
    val offers by vm.offers.collectAsState()
    val isLoading by vm.isLoading.collectAsState()
    val error by vm.error.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    var deletingOfferId by remember { mutableStateOf<String?>(null) }
    var showDeleteError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        vm.loadPendingOffers()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when {
            isLoading -> {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
            error != null -> {
                Text(
                    text = error ?: "",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
            offers.isEmpty() -> {
                Text(
                    text = "Немає пропозицій",
                    modifier = Modifier.align(Alignment.Center)
                )
            }
            else -> {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    offers.forEach { offer ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Замовлення: ${offer.orderDescription ?: "-"}", style = MaterialTheme.typography.titleMedium)
                                Text("Повідомлення: ${offer.message}", style = MaterialTheme.typography.bodyMedium)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(onClick = {
                                        navController.navigate(NavRoutes.orderDetailsRoute(offer.orderId, showCreateOfferButton = false))
                                    }) {
                                        Text("Деталі замовлення")
                                    }
                                    IconButton(
                                        onClick = {
                                            deletingOfferId = offer.id
                                            showDeleteError = null
                                            coroutineScope.launch {
                                                val result = vm.deleteOffer(offer.id)
                                                if (result.isSuccess) {
                                                    vm.loadPendingOffers()
                                                } else {
                                                    showDeleteError = result.exceptionOrNull()?.message ?: "Помилка видалення"
                                                }
                                                deletingOfferId = null
                                            }
                                        },
                                        enabled = deletingOfferId != offer.id
                                    ) {
                                        if (deletingOfferId == offer.id) {
                                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                                        } else {
                                            Icon(Icons.Default.Delete, contentDescription = "Видалити")
                                        }
                                    }
                                }
                                if (showDeleteError != null && deletingOfferId == null) {
                                    Text(
                                        text = showDeleteError ?: "",
                                        color = MaterialTheme.colorScheme.error,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
} 