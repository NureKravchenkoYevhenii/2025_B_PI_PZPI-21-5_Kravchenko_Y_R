package com.example.dicargohub.data.dto

data class AuthTokenResponse(val jwt: String, val refreshToken: String)