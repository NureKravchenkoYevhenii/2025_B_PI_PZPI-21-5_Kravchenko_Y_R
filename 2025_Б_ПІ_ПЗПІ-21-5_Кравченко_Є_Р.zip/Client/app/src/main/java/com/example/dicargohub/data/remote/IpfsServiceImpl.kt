package com.example.dicargohub.data.remote

import io.ipfs.api.IPFS
import io.ipfs.api.MerkleNode
import io.ipfs.api.NamedStreamable
import io.ipfs.multihash.Multihash
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IpfsServiceImpl @Inject constructor() : IpfsService {
    private var ipfs: IPFS? = null
    private val ipfsUrl = "/ip4/192.168.0.102/tcp/5001"

    private suspend fun getIpfs(): IPFS {
        return ipfs ?: withContext(Dispatchers.IO) {
            IPFS(ipfsUrl, ).also { ipfs = it }
        }
    }

    override suspend fun uploadFile(file: File): String = withContext(Dispatchers.IO) {
        val streamable = NamedStreamable.FileWrapper(file)
        val response = getIpfs().add(streamable)[0]
        response.hash.toString()
    }

    override suspend fun uploadFile(inputStream: InputStream, fileName: String): String = withContext(Dispatchers.IO) {
        val streamable = NamedStreamable.InputStreamWrapper(fileName, inputStream)
        val response = getIpfs().add(streamable)[0]
        response.hash.toString()
    }

    override suspend fun uploadFile(bytes: ByteArray, fileName: String): String = withContext(Dispatchers.IO) {
        val streamable = NamedStreamable.ByteArrayWrapper(fileName, bytes)
        val response = getIpfs().add(streamable)[0]
        response.hash.toString()
    }

    override suspend fun getFile(hash: String): ByteArray = withContext(Dispatchers.IO) {
        val multihash = Multihash.fromBase58(hash)
        getIpfs().cat(multihash)
    }

    override suspend fun deleteFile(hash: String): Unit = withContext(Dispatchers.IO) {
        val multihash = Multihash.fromBase58(hash)
        getIpfs().pin.rm(multihash)
    }
} 