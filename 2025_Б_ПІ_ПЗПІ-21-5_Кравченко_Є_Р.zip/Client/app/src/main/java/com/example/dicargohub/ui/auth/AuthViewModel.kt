package com.example.dicargohub.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.dicargohub.data.auth.TokenManager
import com.example.dicargohub.data.dto.AuthTokenResponse
import com.example.dicargohub.data.dto.UserDto
import com.example.dicargohub.data.repo.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class AuthState {
    object Idle: AuthState()
    object Loading: AuthState()
    data class Registered(val user: UserDto): AuthState()
    data class LoggedIn(val token: AuthTokenResponse): AuthState()
    data class Error(val msg: String): AuthState()
}

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val repo: AuthRepository,
    private val tokenManager: TokenManager
): ViewModel() {

    private val _state = MutableStateFlow<AuthState>(AuthState.Idle)
    val state: StateFlow<AuthState> = _state

    fun register(login: String, pwd: String, role: String) = viewModelScope.launch {
        _state.value = AuthState.Loading
        try {
            val user = repo.register(login, pwd, role)
            _state.value = AuthState.Registered(user)
        } catch(e: Exception) {
            _state.value = AuthState.Error(e.localizedMessage ?: "Failed")
        }
    }

    fun login(login: String, pwd: String) = viewModelScope.launch {
        _state.value = AuthState.Loading
        try {
            val tokens = repo.login(login, pwd)
            tokenManager.saveTokens(tokens.jwt, tokens.refreshToken);
            _state.value = AuthState.LoggedIn(tokens)
        } catch(e: Exception) {
            _state.value = AuthState.Error(e.localizedMessage ?: "Failed")
        }
    }
}