package com.example.dicargohub.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.dicargohub.R
import com.example.dicargohub.domain.Role
import com.example.dicargohub.ui.NavRoutes
import com.example.dicargohub.ui.auth.AuthStateHolder

@Composable
fun BottomNavBar(
    navController: NavController,
    authStateHolder: AuthStateHolder,
    modifier: Modifier = Modifier
) {
    val userRole by authStateHolder.userRole.collectAsState()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surfaceVariant
    ) {
        when (userRole) {
            Role.CUSTOMER -> {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.List, contentDescription = stringResource(R.string.nav_my_orders)) },
                    label = { Text(stringResource(R.string.nav_my_orders)) },
                    selected = currentRoute == NavRoutes.ORDERS_LIST,
                    onClick = {
                        if (currentRoute != NavRoutes.ORDERS_LIST) {
                            navController.navigate(NavRoutes.ORDERS_LIST) {
                                popUpTo(NavRoutes.ORDERS_LIST) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.History, contentDescription = stringResource(R.string.nav_history)) },
                    label = { Text(stringResource(R.string.nav_history)) },
                    selected = currentRoute == NavRoutes.HISTORY,
                    onClick = {
                        if (currentRoute != NavRoutes.HISTORY) {
                            navController.navigate(NavRoutes.HISTORY) {
                                popUpTo(NavRoutes.ORDERS_LIST) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Person, contentDescription = stringResource(R.string.nav_profile)) },
                    label = { Text(stringResource(R.string.nav_profile)) },
                    selected = currentRoute == NavRoutes.PROFILE,
                    onClick = {
                        if (currentRoute != NavRoutes.PROFILE) {
                            navController.navigate(NavRoutes.PROFILE) {
                                popUpTo(NavRoutes.ORDERS_LIST) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                )
            }
            Role.CARRIER -> {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.DirectionsCar, contentDescription = stringResource(R.string.nav_transport)) },
                    label = { Text(stringResource(R.string.nav_transport)) },
                    selected = currentRoute == NavRoutes.TRANSPORT_LIST,
                    onClick = {
                        if (currentRoute != NavRoutes.TRANSPORT_LIST) {
                            navController.navigate(NavRoutes.TRANSPORT_LIST) {
                                popUpTo(NavRoutes.ORDERS_SEARCH) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.List, contentDescription = stringResource(R.string.nav_orders)) },
                    label = { Text(stringResource(R.string.nav_orders)) },
                    selected = currentRoute == NavRoutes.CARRIER_ORDERS_OFFERS,
                    onClick = {
                        if (currentRoute != NavRoutes.CARRIER_ORDERS_OFFERS) {
                            navController.navigate(NavRoutes.CARRIER_ORDERS_OFFERS) {
                                popUpTo(NavRoutes.ORDERS_SEARCH) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.History, contentDescription = stringResource(R.string.nav_history)) },
                    label = { Text(stringResource(R.string.nav_history)) },
                    selected = currentRoute == NavRoutes.CARRIER_ORDER_HISTORY,
                    onClick = {
                        if (currentRoute != NavRoutes.CARRIER_ORDER_HISTORY) {
                            navController.navigate(NavRoutes.CARRIER_ORDER_HISTORY) {
                                popUpTo(NavRoutes.ORDERS_SEARCH) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Person, contentDescription = stringResource(R.string.nav_profile)) },
                    label = { Text(stringResource(R.string.nav_profile)) },
                    selected = currentRoute == NavRoutes.PROFILE,
                    onClick = {
                        if (currentRoute != NavRoutes.PROFILE) {
                            navController.navigate(NavRoutes.PROFILE) {
                                popUpTo(NavRoutes.ORDERS_SEARCH) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                )
            }
            null -> {} // No navigation for unauthenticated users
        }
    }
} 