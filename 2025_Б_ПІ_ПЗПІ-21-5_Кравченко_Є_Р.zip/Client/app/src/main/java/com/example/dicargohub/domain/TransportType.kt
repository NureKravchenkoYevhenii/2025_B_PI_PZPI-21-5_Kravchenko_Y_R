package com.example.dicargohub.domain

import com.google.gson.annotations.SerializedName

enum class TransportType(val displayName: String) {
    @SerializedName("Unknown")
    UNKNOWN("Невідомий"),

    @SerializedName("None")
    NONE("Не вказано"),

    @SerializedName("Truck")
    TRUCK("Вантажівка"),

    @SerializedName("Van")
    VAN("Фургон"),

    @SerializedName("Refrigerated")
    REFRIGERATED("Рефрижератор"),

    @SerializedName("Tanker")
    TANKER("Танкер"),

    @SerializedName("Container")
    CONTAINER("Контейнер")
}